import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.navigateToUrl('http://gandhimmm.org/')

WebUI.click(findTestObject('Object Repository/Page_Gandhi Memorial Museum  Official websi_820753/div_'))

WebUI.click(findTestObject('Object Repository/Page_Gandhi Memorial Museum  Official websi_820753/div_You are using an insecure version of. P_a8ce5e'))

WebUI.click(findTestObject('Object Repository/Page_Gandhi Memorial Museum  Official websi_820753/div__1'))

WebUI.click(findTestObject('Object Repository/Page_Gandhi Memorial Museum  Official websi_820753/a_Gandhi Memorial Museum'))

WebUI.click(findTestObject('Object Repository/Page_Gandhi Memorial Museum  Official websi_820753/div__1'))

WebUI.click(findTestObject('Object Repository/Page_Gandhi Memorial Museum  Official websi_820753/h3_Navigation'))

WebUI.click(findTestObject('Object Repository/Page_Gandhi Memorial Museum  Official websi_820753/a_Eminent Visitors'))

WebUI.click(findTestObject('Object Repository/Page_Eminent Visitors  Gandhi Memorial Museum/font_Ahimsa is                         the _41da13'))

WebUI.click(findTestObject('Object Repository/Page_Eminent Visitors  Gandhi Memorial Museum/h3_Gandhi Memorial Museum Guide Book'))

WebUI.click(findTestObject('Object Repository/Page_Eminent Visitors  Gandhi Memorial Museum/img'))

WebUI.click(findTestObject('Object Repository/Page_Eminent Visitors  Gandhi Memorial Museum/img_concat(id(, , shTopImg, , ))_shTopImg'))

WebUI.click(findTestObject('Object Repository/Page_Eminent Visitors  Gandhi Memorial Museum/img_concat(id(, , shTopImg, , ))_shTopImg'))

WebUI.click(findTestObject('Object Repository/Page_Eminent Visitors  Gandhi Memorial Museum/h3_GANDHI MUSEUM FORUM Concluding Ceremony _8d3dcb'))

WebUI.click(findTestObject('Object Repository/Page_Eminent Visitors  Gandhi Memorial Museum/a_Museum Galleries'))

WebUI.click(findTestObject('Object Repository/Page_Museum Galleries  Gandhi Memorial Museum/span_The Museum galleries are divided into _309776'))

WebUI.click(findTestObject('Object Repository/Page_Museum Galleries  Gandhi Memorial Museum/h3_News and Events'))

WebUI.click(findTestObject('Object Repository/Page_Museum Galleries  Gandhi Memorial Museum/a_Photo Gallery'))

WebUI.click(findTestObject('Object Repository/Page_Photo Gallery  Gandhi Memorial Museum/img'))

WebUI.click(findTestObject('Object Repository/Page_Photo Gallery  Gandhi Memorial Museum/img_concat(id(, , shTopImg, , ))_shTopImg'))

WebUI.click(findTestObject('Object Repository/Page_Photo Gallery  Gandhi Memorial Museum/img_1'))

WebUI.click(findTestObject('Object Repository/Page_Photo Gallery  Gandhi Memorial Museum/img_concat(id(, , shTopImg, , ))_shTopImg_1'))

WebUI.click(findTestObject('Object Repository/Page_Photo Gallery  Gandhi Memorial Museum/div_Show as slideshow'))

WebUI.click(findTestObject('Object Repository/Page_Photo Gallery  Gandhi Memorial Museum/img_1_2'))

WebUI.click(findTestObject('Object Repository/Page_Photo Gallery  Gandhi Memorial Museum/img_concat(id(, , shTopImg, , ))_shTopImg_1_2'))

WebUI.click(findTestObject('Object Repository/Page_Photo Gallery  Gandhi Memorial Museum/a_About us'))

WebUI.click(findTestObject('Object Repository/Page_About us  Gandhi Memorial Museum/span_To propgate the Gandhian messege of Tr_37fe4a'))

WebUI.click(findTestObject('Object Repository/Page_About us  Gandhi Memorial Museum/span_Mission'))

WebUI.click(findTestObject('Object Repository/Page_About us  Gandhi Memorial Museum/span_Objectives'))

WebUI.click(findTestObject('Object Repository/Page_About us  Gandhi Memorial Museum/p_To establish a global centre for training_8de079'))

WebUI.click(findTestObject('Object Repository/Page_About us  Gandhi Memorial Museum/td'))

WebUI.click(findTestObject('Object Repository/Page_About us  Gandhi Memorial Museum/strong_Shri. K. HARI THIAGARAJAN,'))

WebUI.click(findTestObject('Object Repository/Page_About us  Gandhi Memorial Museum/strong_Shri A. ANNAMALAI'))

WebUI.click(findTestObject('Object Repository/Page_About us  Gandhi Memorial Museum/strong_D. BALASUNDARAM,'))

WebUI.click(findTestObject('Object Repository/Page_About us  Gandhi Memorial Museum/strong_Shri T.S.R. Venkatramana'))

WebUI.click(findTestObject('Object Repository/Page_About us  Gandhi Memorial Museum/strong_SECRETARY, Dept. of Culture, New Del_71b4b4'))

WebUI.click(findTestObject('Object Repository/Page_About us  Gandhi Memorial Museum/strong_SECRETARY Dept. of Tourism and Cultu_830ac2'))

WebUI.click(findTestObject('Object Repository/Page_About us  Gandhi Memorial Museum/strong_STAFF'))

WebUI.click(findTestObject('Object Repository/Page_About us  Gandhi Memorial Museum/span_MUSEUM'))

WebUI.click(findTestObject('Object Repository/Page_About us  Gandhi Memorial Museum/p_OFFICE'))

WebUI.click(findTestObject('Object Repository/Page_About us  Gandhi Memorial Museum/strong_D. SUMITHRA'))

WebUI.click(findTestObject('Object Repository/Page_About us  Gandhi Memorial Museum/strong_Mr.R. Natarajan'))

WebUI.click(findTestObject('Object Repository/Page_About us  Gandhi Memorial Museum/td_Curator ic.  Education Officer  P.I.O'))

WebUI.click(findTestObject('Object Repository/Page_About us  Gandhi Memorial Museum/td_Accountant'))

WebUI.click(findTestObject('Object Repository/Page_About us  Gandhi Memorial Museum/strong_V. SOLAMALAI'))

WebUI.click(findTestObject('Object Repository/Page_About us  Gandhi Memorial Museum/strong_RESEARCH'))

WebUI.click(findTestObject('Object Repository/Page_About us  Gandhi Memorial Museum/p_LIBRARY'))

WebUI.click(findTestObject('Object Repository/Page_About us  Gandhi Memorial Museum/p_CAMPUS'))

WebUI.click(findTestObject('Object Repository/Page_About us  Gandhi Memorial Museum/td_P. DANAPANDI'))

WebUI.click(findTestObject('Object Repository/Page_About us  Gandhi Memorial Museum/strong_M. MUTHU KANNAN'))

WebUI.acceptAlert()

WebUI.acceptAlert()

