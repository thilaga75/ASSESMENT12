import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/div_Latest at TIDEL                        _4fb7c2'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/img_MRTS Overpass_icon-100'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/img_Promotional Space_icon-100'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/img_Banking  ATM Services_icon-100'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/img'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/img_1'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/img_TIDEL_gallery-img'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/div_Previous_slick-lightbox-slick-item slic_4c418c'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/img_TIDEL_gallery-img_1'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/img_Previous_slick-lightbox-slick-img'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/div_Previous_slick-lightbox-slick-item slic_4c418c'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/img_1_2'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/img_1_2_3'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/img_1_2_3_4'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/h1_Testimonials'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/img_1_2_3_4_5'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/img_1_2_3'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/img_1_2'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/span_SEE MORE'))

WebUI.navigateToUrl('https://www.tidelpark.com/why-tidel#testimonial')

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/select_Choose Building                     _1a704d'), 
    'http://tidelpark.com/why-tidel', true)

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/div_Coimbatore                             _c85709'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/a_Coimbatore'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/a_Coimbatore_1'))

WebUI.click(findTestObject('Object Repository/Page_/td_SA-GF-02'))

WebUI.click(findTestObject('Object Repository/Page_/td_Immediate'))

WebUI.click(findTestObject('Object Repository/Page_/td_SA-TF-04'))

WebUI.click(findTestObject('Object Repository/Page_/td_Third Floor'))

WebUI.click(findTestObject('Object Repository/Page_/a_About Us'))

WebUI.click(findTestObject('Object Repository/Page_Commercial office space for rent  TIDEL Park/span_Icon. Landmark. Identity'))

WebUI.click(findTestObject('Object Repository/Page_Commercial office space for rent  TIDEL Park/div_Watch the legacy of_sonar-wrapper'))

WebUI.click(findTestObject('Object Repository/Page_Commercial office space for rent  TIDEL Park/video_concat(TIDEL Park Empowering Tamil Nadu, , s IT Future)_video-stream html5-main-video'))

WebUI.doubleClick(findTestObject('Object Repository/Page_Commercial office space for rent  TIDEL Park/video_concat(TIDEL Park Empowering Tamil Nadu, , s IT Future)_video-stream html5-main-video'))

WebUI.click(findTestObject('Object Repository/Page_Commercial office space for rent  TIDEL Park/video_concat(TIDEL Park Empowering Tamil Nadu, , s IT Future)_video-stream html5-main-video'))

WebUI.click(findTestObject('Object Repository/Page_Commercial office space for rent  TIDEL Park/div_X'))

WebUI.click(findTestObject('Object Repository/Page_Commercial office space for rent  TIDEL Park/div_Watch the legacy of_col-xl-1 col-lg-1 col-md-1'))

WebUI.click(findTestObject('Object Repository/Page_Commercial office space for rent  TIDEL Park/img'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/h3_Saraswathy K'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/span_Chief Executive Officer, Pointel Solut_0cdfcf'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/h3_Kalyan'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/span_Greenbooks'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/h1_Testimonials'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/p_First hand experiences from the best orga_9c083a'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/p_TIDEL provides an excellent stress-free w_071478'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/p_First hand experiences from the best orga_9c083a'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/h3_Narasimha NK'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/span_Enquiry'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/div_Sep 02, 2022'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/div_Dec 08, 2023'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/img_1_2_3_4_5_6'))

WebUI.click(findTestObject('Object Repository/Page_Best Strategic Office spaces for IT  I_ece1b7/img_1_2_3_4_5_6_7'))

WebUI.click(findTestObject('Object Repository/Page_TIDEL Park - Pattabiram/p_Interesting tidbits, event highlights, wo_a5d023'))

WebUI.click(findTestObject('Object Repository/Page_TIDEL Park - Pattabiram/span_The Essential Guide'))

WebUI.click(findTestObject('Object Repository/Page_TIDEL Park - Pattabiram/img'))

WebUI.click(findTestObject('Object Repository/Page_TIDEL Park - Pattabiram/p_TIDEL is establishing an Information Tech_ce33bb'))

WebUI.click(findTestObject('Object Repository/Page_TIDEL Park - Pattabiram/b_TIDEL Park, Chennai is constructing an In_d5e541'))

WebUI.click(findTestObject('Object Repository/Page_TIDEL Park - Pattabiram/b_TIDEL Pattabiram'))

WebUI.click(findTestObject('Object Repository/Page_TIDEL Park - Pattabiram/span_Super admin'))

WebUI.click(findTestObject('Object Repository/Page_TIDEL Park - Pattabiram/span_September 02, 2022'))

WebUI.click(findTestObject('Object Repository/Page_TIDEL Park - Pattabiram/div_Super admin                            _114f5a'))

WebUI.click(findTestObject('Object Repository/Page_TIDEL Park - Pattabiram/h4_TIDEL Park - Pattabiram'))

WebUI.click(findTestObject('Object Repository/Page_TIDEL Park - Pattabiram/b_This New TIDEL in Pattabiram is a 21-stor_e85ea2'))

WebUI.click(findTestObject('Object Repository/Page_TIDEL Park - Pattabiram/b_The proposed new TIDEL will act as the ad_cf7e4f'))

WebUI.click(findTestObject('Object Repository/Page_TIDEL Park - Pattabiram/img_1'))

WebUI.click(findTestObject('Object Repository/Page_TIDEL Park - Pattabiram/button_Submit'))

WebUI.click(findTestObject('Object Repository/Page_TIDEL Park - Pattabiram/a_TIDEL Park - Pattabiram'))

WebUI.click(findTestObject('Object Repository/Page_TIDEL Park - Pattabiram/img_1'))

WebUI.click(findTestObject('Object Repository/Page_TIDEL Park - Pattabiram/form_Comment Posted Successfully           _197818'))

WebUI.click(findTestObject('Object Repository/Page_TIDEL Park - Pattabiram/label_Email'))

WebUI.click(findTestObject('Object Repository/Page_TIDEL Park - Pattabiram/label_Comment'))

WebUI.click(findTestObject('Object Repository/Page_TIDEL Park - Pattabiram/label_Name'))

WebUI.click(findTestObject('Object Repository/Page_TIDEL Park - Pattabiram/h3_Post Comment'))

WebUI.click(findTestObject('Object Repository/Page_TIDEL Park - Pattabiram/div_Comment Posted Successfully'))

WebUI.click(findTestObject('Object Repository/Page_TIDEL Park - Pattabiram/h3_Comment'))

WebUI.click(findTestObject('Object Repository/Page_TIDEL Park - Pattabiram/div_Comment                                _311a0a'))

WebUI.click(findTestObject('Object Repository/Page_TIDEL Park - Pattabiram/h3_About Us'))

WebUI.click(findTestObject('Object Repository/Page_TIDEL Park - Pattabiram/a_Board of Directors'))

WebUI.click(findTestObject('Object Repository/Page_Commercial office space for rent  TIDEL Park/img_Thiru. J. Chakrapani_rounded-circle'))

WebUI.click(findTestObject('Object Repository/Page_Commercial office space for rent  TIDEL Park/img_Thiru. Ganda Rajeswara Reddy_rounded-circle'))

WebUI.click(findTestObject('Object Repository/Page_Commercial office space for rent  TIDEL Park/img_Thiru. M V R Murali Krishna_rounded-circle'))

WebUI.click(findTestObject('Object Repository/Page_Commercial office space for rent  TIDEL Park/p_GM Network I, Chennai CircleState Bank of India'))

WebUI.click(findTestObject('Object Repository/Page_Commercial office space for rent  TIDEL Park/p_Field General ManagerIndian Bank'))

WebUI.click(findTestObject('Object Repository/Page_Commercial office space for rent  TIDEL Park/p_General ManagerHyundai Engineering  Const_98215c'))

WebUI.click(findTestObject('Object Repository/Page_Commercial office space for rent  TIDEL Park/div_Thiru. V. Arun Roy IAS                 _f644b5'))

WebUI.click(findTestObject('Object Repository/Page_Commercial office space for rent  TIDEL Park/h4_Thiru. Sandeep Nanduri, IAS'))

WebUI.click(findTestObject('Object Repository/Page_Commercial office space for rent  TIDEL Park/h4_Thiru. Prashant M. Wadnere, IAS'))

WebUI.click(findTestObject('Object Repository/Page_Commercial office space for rent  TIDEL Park/p_SpecialSecretary to GovernmentFinance Department'))

WebUI.click(findTestObject('Object Repository/Page_Commercial office space for rent  TIDEL Park/p_Managing DirectorTIDCO  TIDEL'))

WebUI.click(findTestObject('Object Repository/Page_Commercial office space for rent  TIDEL Park/p_Secretary to Government - Industries Depa_c6898a'))

WebUI.click(findTestObject('Object Repository/Page_Commercial office space for rent  TIDEL Park/h4_Thiru. V. Arun Roy IAS'))

WebUI.click(findTestObject('Object Repository/Page_Commercial office space for rent  TIDEL Park/h4_Thiru. Sandeep Nanduri, IAS'))

WebUI.click(findTestObject('Object Repository/Page_Commercial office space for rent  TIDEL Park/p_Managing DirectorTIDCO  TIDEL'))

WebUI.click(findTestObject('Object Repository/Page_Commercial office space for rent  TIDEL Park/h4_Thiru. Prashant M. Wadnere, IAS'))

WebUI.click(findTestObject('Object Repository/Page_Commercial office space for rent  TIDEL Park/p_SpecialSecretary to GovernmentFinance Department'))

WebUI.click(findTestObject('Object Repository/Page_Commercial office space for rent  TIDEL Park/a_Coimbatore'))

WebUI.click(findTestObject('Object Repository/Page_/span_March Ahead'))

WebUI.click(findTestObject('Object Repository/Page_/p_For businesses that go places, TIDEL is t_9b7ea7'))

WebUI.click(findTestObject('Object Repository/Page_/img_Visitor Pass_banner-img'))

WebUI.click(findTestObject('Object Repository/Page_/img_Visitor Pass_banner-img'))

WebUI.click(findTestObject('Object Repository/Page_/h5_b. Commercial  Retail'))

WebUI.click(findTestObject('Object Repository/Page_/th_Counter'))

WebUI.click(findTestObject('Object Repository/Page_/th_Module No'))

WebUI.click(findTestObject('Object Repository/Page_/th_Area in Sq. Ft'))

WebUI.click(findTestObject('Object Repository/Page_/th_Ready for Occupation'))

WebUI.click(findTestObject('Object Repository/Page_/th_Floor Status'))

WebUI.click(findTestObject('Object Repository/Page_/th_Enquire'))

WebUI.click(findTestObject('Object Repository/Page_/h4_Space Availability  PR  Media'))

WebUI.click(findTestObject('Object Repository/Page_/span_KEY CONTACTS'))

WebUI.click(findTestObject('Object Repository/Page_/h4_Tenders'))

WebUI.click(findTestObject('Object Repository/Page_/p_R Sendhil MuruganChief Operating Officer9_9d9cc6'))

WebUI.click(findTestObject('Object Repository/Page_/p_M Gita Company Secretary  Head - Client R_708915'))

WebUI.click(findTestObject('Object Repository/Page_/h1_Subscribe Now to Our Newsletter'))

WebUI.click(findTestObject('Object Repository/Page_/input_text'))

WebUI.click(findTestObject('Object Repository/Page_/a_Why TIDEL'))

WebUI.click(findTestObject('Object Repository/Page_/a_Why TIDEL'))

WebUI.click(findTestObject('Object Repository/Page_/a_Facilities'))

WebUI.click(findTestObject('Object Repository/Page_/a_Why TIDEL'))

WebUI.click(findTestObject('Object Repository/Page_/a_Highlights'))

WebUI.click(findTestObject('Object Repository/Page_/a_Why TIDEL'))

WebUI.switchToWindowTitle('Home Page')

WebUI.click(findTestObject('Object Repository/Page_Home Page/a_Find Space'))

WebUI.click(findTestObject('Object Repository/Page_About Us Tidel/a_Tenders'))

WebUI.click(findTestObject('Object Repository/Page_About Us Tidel/a_Tenders'))

WebUI.click(findTestObject('Object Repository/Page_/a_Latest Blogs'))

WebUI.click(findTestObject('Object Repository/Page_/a_Support'))

WebUI.click(findTestObject('Object Repository/Page_/a_Key Contacts'))

WebUI.click(findTestObject('Object Repository/Page_/a_Tenders'))

WebUI.click(findTestObject('Object Repository/Page_/p_E-TENDER FOR INSURANCE POLICIES FOR ITITE_24c5e1'))

WebUI.switchToWindowTitle('')

WebUI.click(findTestObject('Object Repository/Page_/th_Tender Type'))

