<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h3_GANDHI MUSEUM FORUM Concluding Ceremony _8d3dcb</name>
   <tag></tag>
   <elementGuidId>67e1f8b4-24b8-49d0-b407-637bf40fc3df</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#media_video-2 > h3</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[@id='media_video-2']/h3</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;GANDHI MUSEUM FORUM Concluding Ceremony of 150th Birth Anniversary of Mahatma Gandhi&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
      <webElementGuid>8c04ef4c-8da0-4fb4-b876-dc2b814c6a69</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>GANDHI MUSEUM FORUM Concluding Ceremony of 150th Birth Anniversary of Mahatma Gandhi</value>
      <webElementGuid>1fbfc4d6-c9c7-4234-aa9a-ac7f54e025dd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;media_video-2&quot;)/h3[1]</value>
      <webElementGuid>48a065af-998e-4465-9c12-54dc1385c1ff</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//li[@id='media_video-2']/h3</value>
      <webElementGuid>2ad0b551-c536-4242-b95d-09b91f24966e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Visual Biography of Mahatma Gandhi Quotes'])[1]/following::h3[1]</value>
      <webElementGuid>cf41e36d-06b8-4b65-9214-f5edea036f4e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Photo Gallery'])[1]/following::h3[1]</value>
      <webElementGuid>aa163ba4-48be-41f3-8f3a-e3c61ebbc124</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Video Player'])[1]/preceding::h3[1]</value>
      <webElementGuid>e8bdaac1-f2d5-44e2-baa5-16a760f457ec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='https://youtu.be/7Blw2zu0MR4'])[1]/preceding::h3[1]</value>
      <webElementGuid>f93d4005-753e-4a8a-a112-073f8fe4a6c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='GANDHI MUSEUM FORUM Concluding Ceremony of 150th Birth Anniversary of Mahatma Gandhi']/parent::*</value>
      <webElementGuid>c380f911-0cb3-4f3b-a8c3-5a83433bd8c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[3]/h3</value>
      <webElementGuid>6e431810-c576-4aea-990c-ceb08099e95c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h3[(text() = 'GANDHI MUSEUM FORUM Concluding Ceremony of 150th Birth Anniversary of Mahatma Gandhi' or . = 'GANDHI MUSEUM FORUM Concluding Ceremony of 150th Birth Anniversary of Mahatma Gandhi')]</value>
      <webElementGuid>1efe879d-8064-46c4-89ac-88d3e9bf6bb3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
