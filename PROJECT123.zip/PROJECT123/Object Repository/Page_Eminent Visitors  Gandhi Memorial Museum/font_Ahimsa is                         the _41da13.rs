<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>font_Ahimsa is                         the _41da13</name>
   <tag></tag>
   <elementGuidId>bddd3000-9021-42c3-bff5-656a446bf16b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>font > font > font > font</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[@id='text-2']/div/marquee/p/font/font/font/font</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;\&quot;Ahimsa is the highest duty. Even if we cannot practice it in full, We must try &quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>font</value>
      <webElementGuid>1092e2c7-67db-4aad-9ed8-7c27f8dce16f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>color</name>
      <type>Main</type>
      <value>navy</value>
      <webElementGuid>f9a5cc13-d295-4d4b-a13a-0acd704f6208</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> &quot;Ahimsa is 
                        the highest duty. Even if we cannot practice it in full, 
                        We must try to understand its spirit and refrain as far 
                        as is humanly possibile form violence&quot;</value>
      <webElementGuid>76916dbe-497d-42bc-a627-e2908302b084</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;text-2&quot;)/div[@class=&quot;textwidget&quot;]/marquee[1]/p[1]/font[1]/font[1]/font[1]/font[1]</value>
      <webElementGuid>a7ee6f68-6eb3-41a0-872b-e2efd2829042</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//li[@id='text-2']/div/marquee/p/font/font/font/font</value>
      <webElementGuid>6ed958da-419f-4293-b24c-9d4225a65d73</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='News and Events'])[1]/following::font[4]</value>
      <webElementGuid>30c23ea5-38b0-4fdf-b3a1-f97631746eee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Use Up/Down Arrow keys to increase or decrease volume.'])[1]/following::font[4]</value>
      <webElementGuid>1a6eac57-52be-4c04-b89a-29088f36cf0c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gandhi Memorial Museum Guide Book'])[1]/preceding::font[2]</value>
      <webElementGuid>6c44dde4-86f4-4141-9adc-336e6981ade4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download'])[1]/preceding::font[2]</value>
      <webElementGuid>186a6c2a-ef37-41b1-8b74-c96b1758aa30</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//font/font/font/font</value>
      <webElementGuid>81c157a9-0d90-4c6e-a2ca-e296d6248f1b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//font[(text() = ' &quot;Ahimsa is 
                        the highest duty. Even if we cannot practice it in full, 
                        We must try to understand its spirit and refrain as far 
                        as is humanly possibile form violence&quot;' or . = ' &quot;Ahimsa is 
                        the highest duty. Even if we cannot practice it in full, 
                        We must try to understand its spirit and refrain as far 
                        as is humanly possibile form violence&quot;')]</value>
      <webElementGuid>d116c70c-a584-4246-b9e3-858420b26b66</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
