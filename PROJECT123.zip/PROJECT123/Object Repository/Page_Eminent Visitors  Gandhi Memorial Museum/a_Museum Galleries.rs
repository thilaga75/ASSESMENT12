<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Museum Galleries</name>
   <tag></tag>
   <elementGuidId>29da5184-49a4-4f8d-9422-e404fd75d990</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.page_item.page-item-68 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[@id='pages-2']/ul/li[6]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Museum Galleries&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>00a12f95-611d-4941-90ec-c5ac3bff192a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>http://gandhimmm.org/museum-galleries/</value>
      <webElementGuid>d29859f9-fc4d-44ae-b2f8-cedeb98de048</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Museum Galleries</value>
      <webElementGuid>0dcf2291-5450-48dd-9dec-1781e9bc3e86</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;pages-2&quot;)/ul[1]/li[@class=&quot;page_item page-item-68&quot;]/a[1]</value>
      <webElementGuid>9d6b6547-21d4-4f1f-acf4-c16ba6d6e0d0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//li[@id='pages-2']/ul/li[6]/a</value>
      <webElementGuid>5d0bfca7-d4b2-44ca-993e-66949564eeea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Museum Galleries')]</value>
      <webElementGuid>f69c5e8a-05f6-4fcb-aa63-a9ae9f8b3e00</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Library'])[1]/following::a[1]</value>
      <webElementGuid>b5f7d1d6-79ee-4e85-a896-8c976c368f05</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gandhi Museums in India'])[1]/following::a[2]</value>
      <webElementGuid>6163720d-da8b-4886-b99a-1f4324172a26</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Photo Gallery'])[1]/preceding::a[1]</value>
      <webElementGuid>67f4b740-25e8-49ba-8eb6-c22a77c7fe91</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Visual Biography of Mahatma Gandhi Quotes'])[1]/preceding::a[2]</value>
      <webElementGuid>8079ae25-88be-4f1c-af4b-7c0371cc14d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Museum Galleries']/parent::*</value>
      <webElementGuid>75efb06a-79ab-4192-a2d9-a121ae92df62</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[@href='http://gandhimmm.org/museum-galleries/']</value>
      <webElementGuid>4e4a699a-29e9-419b-bde7-8c5579219142</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[6]/a</value>
      <webElementGuid>0f911651-1af4-46bf-9876-74c8f0f6f3af</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'http://gandhimmm.org/museum-galleries/' and (text() = 'Museum Galleries' or . = 'Museum Galleries')]</value>
      <webElementGuid>752d96f1-3bb3-4950-a424-379789921655</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
