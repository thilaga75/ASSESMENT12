<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h3_Gandhi Memorial Museum Guide Book</name>
   <tag></tag>
   <elementGuidId>143b4e5f-d1a8-4e46-ae84-d2c3fbbd9358</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#custom_html-2 > h3</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[@id='custom_html-2']/h3</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Gandhi Memorial Museum Guide Book&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
      <webElementGuid>d1c44f3d-22a9-4adf-b7ba-f6f92335f5da</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Gandhi Memorial Museum Guide Book</value>
      <webElementGuid>888bdc73-4a24-4ef8-9c8c-0872c5c22593</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;custom_html-2&quot;)/h3[1]</value>
      <webElementGuid>020cecef-3ea9-476c-b50a-e27b9092ef76</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//li[@id='custom_html-2']/h3</value>
      <webElementGuid>fd982b9e-cecb-4f9e-af83-6398b72bb95a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='News and Events'])[1]/following::h3[1]</value>
      <webElementGuid>47e2484b-f01b-446d-b842-11327ab9c76f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Use Up/Down Arrow keys to increase or decrease volume.'])[1]/following::h3[2]</value>
      <webElementGuid>d3abfe4f-96df-4ffe-bd88-4890af09930a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download'])[1]/preceding::h3[1]</value>
      <webElementGuid>3e7f3766-8f15-42ac-a26f-ef3f4fb3b73c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gandhi 150 Celebrations'])[1]/preceding::h3[1]</value>
      <webElementGuid>9e5a9c80-1d51-4cc9-b3e7-c81d38c5472c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Gandhi Memorial Museum Guide Book']/parent::*</value>
      <webElementGuid>ff8dec2f-f041-4121-8793-ffa95b04f0c3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/ul/li[2]/h3</value>
      <webElementGuid>223e3045-d029-45b3-8db0-a4a134724733</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h3[(text() = 'Gandhi Memorial Museum Guide Book' or . = 'Gandhi Memorial Museum Guide Book')]</value>
      <webElementGuid>103008d6-b3d5-46fd-96d5-552aad1613af</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
