<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Show as slideshow</name>
   <tag></tag>
   <elementGuidId>b2525d5a-786a-4450-af6f-10551b79129a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#ngg-gallery-b93c3e1f67596a1539c74560d55d34b2-1</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='ngg-gallery-b93c3e1f67596a1539c74560d55d34b2-1']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#post-72 div >> internal:has-text=&quot;[Show as slideshow]&quot;i >> nth=3</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>9573482c-509e-41aa-9379-4ee399082a2c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ngg-galleryoverview default-view  ngg-ajax-pagination-none</value>
      <webElementGuid>79ba4e0b-d283-4724-8dce-72771aa99794</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>ngg-gallery-b93c3e1f67596a1539c74560d55d34b2-1</value>
      <webElementGuid>856eed78-afc9-4eb4-9d71-282aee2d87df</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

		
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
	
	

		
        [Show as slideshow]
		
	
	
		
		</value>
      <webElementGuid>53f19815-f5e9-48e2-bc2e-5bfec1b16961</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ngg-gallery-b93c3e1f67596a1539c74560d55d34b2-1&quot;)</value>
      <webElementGuid>9d29749f-ffd3-4aa8-937b-31a5bdc1d595</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//div[@id='ngg-gallery-b93c3e1f67596a1539c74560d55d34b2-1']</value>
      <webElementGuid>bda1701e-c5e6-44f1-88b6-f114a0616081</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='post-72']/div/div[2]</value>
      <webElementGuid>c965f9c2-8ece-49f9-b274-8aa67f785f78</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='[Show as slideshow]'])[1]/following::div[2]</value>
      <webElementGuid>7eb4226a-0953-47ad-b061-8906fc7848f6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Photo Gallery'])[1]/following::div[35]</value>
      <webElementGuid>fa8f5f3f-1529-41ce-b419-9fbbb7ea64ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search for:'])[1]/preceding::div[35]</value>
      <webElementGuid>d42b0489-dbeb-40ea-a94c-67db555471ee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div/div/div/div[2]</value>
      <webElementGuid>d1025ffe-d72b-4110-bc32-9b23ce20ade0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[@id = 'ngg-gallery-b93c3e1f67596a1539c74560d55d34b2-1' and (text() = '

		
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
	
	

		
        [Show as slideshow]
		
	
	
		
		' or . = '

		
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
				
				        
            
                
            
        
							 
			
	
	

		
        [Show as slideshow]
		
	
	
		
		')]</value>
      <webElementGuid>11beb297-da86-485b-bdfb-3f9770c71a63</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
