<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h3_News and Events</name>
   <tag></tag>
   <elementGuidId>ac680895-bdac-486e-8e74-e3bf8da520f4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#text-2 > h3</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[@id='text-2']/h3</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;News and Events&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
      <webElementGuid>7aeab5cf-3006-4a2e-b948-90d994d3e061</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>News and Events</value>
      <webElementGuid>08eda70c-3432-4bae-8334-7f4297a682cb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;text-2&quot;)/h3[1]</value>
      <webElementGuid>673b921b-2a98-40da-a3af-28f26cbecd88</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//li[@id='text-2']/h3</value>
      <webElementGuid>b82c66d3-4599-4e30-85b2-287f6130a2e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Use Up/Down Arrow keys to increase or decrease volume.'])[1]/following::h3[1]</value>
      <webElementGuid>c15acf6d-c010-428a-befc-94e797f2e9c5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='https://youtu.be/7Blw2zu0MR4'])[1]/following::h3[1]</value>
      <webElementGuid>148b5688-127e-4f3a-9fd1-64c39d7561bb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gandhi Memorial Museum Guide Book'])[1]/preceding::h3[1]</value>
      <webElementGuid>cd5fcfdd-25d8-4820-a846-b82875d5a3a5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download'])[1]/preceding::h3[2]</value>
      <webElementGuid>ba13370a-cae4-4a5c-a51d-2a74f8274051</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='News and Events']/parent::*</value>
      <webElementGuid>6cd39768-33f3-4622-a43d-9442a6cb8ea5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/ul/li/h3</value>
      <webElementGuid>c0bd29e9-f8af-48b1-9824-e95721230069</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h3[(text() = 'News and Events' or . = 'News and Events')]</value>
      <webElementGuid>fb3b7904-413c-403f-88ef-0880243e2929</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
