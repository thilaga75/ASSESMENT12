<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_The Museum galleries are divided into _309776</name>
   <tag></tag>
   <elementGuidId>b4650e6c-36f9-4dc5-9739-00ff5037a2a0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p > span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='post-68']/div/p/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;The Museum galleries are divided into three major sections, viz., “India Fights &quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>d143d28c-2947-4786-812e-226fa518f7de</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> The Museum galleries are divided into three major sections, viz., “India Fights for Freedom”, “Visual Biography of Mahatma Gandhi” and “Relics and Replicas”.  Also a Philatelic Gallery on Gandhi is functioning in the ground floor.</value>
      <webElementGuid>a4155e8a-55e2-40a1-af05-31aba8f70e58</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;post-68&quot;)/div[@class=&quot;storycontent&quot;]/p[1]/span[1]</value>
      <webElementGuid>81ff7262-22fc-4219-b4f3-05fd21287476</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='post-68']/div/p/span</value>
      <webElementGuid>b0948421-fdac-4855-8ece-86c868de4a65</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Museum Galleries'])[1]/following::span[1]</value>
      <webElementGuid>75b17173-8a1f-4d84-8d4b-160f78f51244</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Official website of Gandhi Memorial Museum Madurai'])[1]/following::span[1]</value>
      <webElementGuid>21d7dc96-a373-4c7a-bafd-0a874100a293</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='INDIAN FIGHTS FOR FREEDOM'])[1]/preceding::span[1]</value>
      <webElementGuid>785e92a7-7f1d-45f3-8dd5-c1f9c0911ced</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='THE COMING OF THE WHITE MEN-1498'])[1]/preceding::span[1]</value>
      <webElementGuid>3078efcb-ea63-413a-b39c-e4dd18357c70</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p/span</value>
      <webElementGuid>d5e6ec88-0394-47dd-adb3-01736af5498a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = ' The Museum galleries are divided into three major sections, viz., “India Fights for Freedom”, “Visual Biography of Mahatma Gandhi” and “Relics and Replicas”.  Also a Philatelic Gallery on Gandhi is functioning in the ground floor.' or . = ' The Museum galleries are divided into three major sections, viz., “India Fights for Freedom”, “Visual Biography of Mahatma Gandhi” and “Relics and Replicas”.  Also a Philatelic Gallery on Gandhi is functioning in the ground floor.')]</value>
      <webElementGuid>07dbc892-4470-442b-8c93-7701720f1284</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
