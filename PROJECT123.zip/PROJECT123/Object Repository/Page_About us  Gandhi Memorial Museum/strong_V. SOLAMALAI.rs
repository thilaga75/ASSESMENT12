<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>strong_V. SOLAMALAI</name>
   <tag></tag>
   <elementGuidId>250829b5-72a9-4c9d-b825-03db2615f12e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(13) > td:nth-of-type(2) > strong</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='post-26']/div/table[2]/tbody/tr[13]/td[2]/strong</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;V. SOLAMALAI&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>strong</value>
      <webElementGuid>e96cc642-cf96-46c8-90d2-1a484b3fdbd5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>V. SOLAMALAI</value>
      <webElementGuid>d3868a21-196d-4daa-81e3-c29621062aec</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;post-26&quot;)/div[@class=&quot;storycontent&quot;]/table[2]/tbody[1]/tr[13]/td[2]/strong[1]</value>
      <webElementGuid>b9ae6441-dea1-493e-9c04-5d6714e7c534</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='post-26']/div/table[2]/tbody/tr[13]/td[2]/strong</value>
      <webElementGuid>9738662f-accd-47ce-84d0-054268e3f18e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RESEARCH'])[1]/following::strong[1]</value>
      <webElementGuid>362fcd6d-913a-4f9e-b243-c219c361b04a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gardener'])[1]/following::strong[2]</value>
      <webElementGuid>418dcfa4-a1c6-40fb-a5a4-ffdf46b65de5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Safai Sevak'])[1]/preceding::strong[1]</value>
      <webElementGuid>c4e0ee29-1b0c-4c41-8f54-995e790e6fc3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dr.R. Devadoss'])[1]/preceding::strong[1]</value>
      <webElementGuid>11e99563-3315-4119-92c8-616cb7c66713</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='V. SOLAMALAI']/parent::*</value>
      <webElementGuid>2d49fa4e-0069-4fb5-b70f-449a7d7563f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[13]/td[2]/strong</value>
      <webElementGuid>5a5a20b9-4a30-4cd6-86f3-fe5f7347c356</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//strong[(text() = 'V. SOLAMALAI' or . = 'V. SOLAMALAI')]</value>
      <webElementGuid>4b490de4-bde8-4eaf-a855-569fd3f474b0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
