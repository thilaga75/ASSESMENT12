<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>strong_Shri T.S.R. Venkatramana</name>
   <tag></tag>
   <elementGuidId>04d29abe-5f9d-4235-bb4e-4c956564d7e2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p:nth-of-type(4) > strong</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='post-26']/div/table/tbody/tr[10]/td/p[4]/strong</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Shri T.S.R. Venkatramana&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>strong</value>
      <webElementGuid>566c9aba-c343-4225-858e-ed10f1c5e6f8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Shri T.S.R. Venkatramana</value>
      <webElementGuid>4f0e11fa-33a8-4709-9654-79e7e05027ac</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;post-26&quot;)/div[@class=&quot;storycontent&quot;]/table[1]/tbody[1]/tr[10]/td[1]/p[4]/strong[1]</value>
      <webElementGuid>af3bf533-e3a0-4d40-86d4-743eae0402d2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='post-26']/div/table/tbody/tr[10]/td/p[4]/strong</value>
      <webElementGuid>1fa5936e-2ff8-4ebe-abf9-988d27f5dc7b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shri. K. HARI THIAGARAJAN,'])[1]/following::strong[1]</value>
      <webElementGuid>8c9f837f-e6b9-4624-b149-f9f7022bda4f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shri A. ANNAMALAI'])[1]/following::strong[2]</value>
      <webElementGuid>3d3d306b-09fd-439e-a3fc-557088d45e2e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shri. N. Ramalingam.'])[1]/preceding::strong[1]</value>
      <webElementGuid>ec8fa0fc-46da-4133-a632-855b417bfb86</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SECRETARY, Dept. of Culture, New Delhi. (Ex-Officio Member)'])[1]/preceding::strong[2]</value>
      <webElementGuid>32493ad4-fb94-430b-b15c-99c53fd3d34b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Shri T.S.R. Venkatramana']/parent::*</value>
      <webElementGuid>ebcc2f33-5388-4c7f-88cd-3c67cbcd4643</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[4]/strong</value>
      <webElementGuid>6f0b1bf1-8773-4373-aa54-8c88dc92b774</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//strong[(text() = 'Shri T.S.R. Venkatramana' or . = 'Shri T.S.R. Venkatramana')]</value>
      <webElementGuid>fa2c7d4e-703e-4010-9e81-a19c046984e1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
