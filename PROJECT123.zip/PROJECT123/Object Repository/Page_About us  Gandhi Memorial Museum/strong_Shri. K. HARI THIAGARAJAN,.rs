<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>strong_Shri. K. HARI THIAGARAJAN,</name>
   <tag></tag>
   <elementGuidId>10a8266c-fcac-40d8-a726-e2a0d39c2fbf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p:nth-of-type(3) > strong</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='post-26']/div/table/tbody/tr[10]/td/p[3]/strong</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Shri. K. HARI THIAGARAJAN,&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>strong</value>
      <webElementGuid>a2c33a61-c00f-43eb-8099-f42c8873c5ff</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Shri. K. HARI THIAGARAJAN, </value>
      <webElementGuid>502b2776-3e25-475d-be42-c78d4f25ceda</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;post-26&quot;)/div[@class=&quot;storycontent&quot;]/table[1]/tbody[1]/tr[10]/td[1]/p[3]/strong[1]</value>
      <webElementGuid>2f155a1f-6df4-4ed8-9c06-0b26a2e3eb18</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='post-26']/div/table/tbody/tr[10]/td/p[3]/strong</value>
      <webElementGuid>afc130e1-33a4-4a5d-a00a-c522d15af0e8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shri A. ANNAMALAI'])[1]/following::strong[1]</value>
      <webElementGuid>1d11841f-fd6e-471d-92a0-9c57647c2fae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shri T.S.R. Venkatramana'])[1]/preceding::strong[1]</value>
      <webElementGuid>6ed9b279-222e-4108-8e99-90a7996cf068</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shri. N. Ramalingam.'])[1]/preceding::strong[2]</value>
      <webElementGuid>ca0843b0-d412-4a52-a35a-ecab12ce23ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Shri. K. HARI THIAGARAJAN,']/parent::*</value>
      <webElementGuid>deef42eb-6ae8-4f28-a26c-fd9d96c58371</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[3]/strong</value>
      <webElementGuid>a064e3f3-3755-449a-abb5-496cccde0471</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//strong[(text() = 'Shri. K. HARI THIAGARAJAN, ' or . = 'Shri. K. HARI THIAGARAJAN, ')]</value>
      <webElementGuid>c188209d-f19c-432c-8b54-40901959c7a1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
