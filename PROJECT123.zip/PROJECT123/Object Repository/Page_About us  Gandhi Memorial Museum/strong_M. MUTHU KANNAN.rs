<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>strong_M. MUTHU KANNAN</name>
   <tag></tag>
   <elementGuidId>a0fbbaae-4c82-41f0-845f-d94f63a60853</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(17) > td:nth-of-type(2) > strong</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='post-26']/div/table[2]/tbody/tr[17]/td[2]/strong</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;M. MUTHU KANNAN&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>strong</value>
      <webElementGuid>63442162-d856-4b50-aac6-347a86328de0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>M. MUTHU KANNAN</value>
      <webElementGuid>6e3152b1-671e-49ea-9845-d76ec9a7ca3c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;post-26&quot;)/div[@class=&quot;storycontent&quot;]/table[2]/tbody[1]/tr[17]/td[2]/strong[1]</value>
      <webElementGuid>0c9da36e-00ac-4460-bb77-ce8cbc836a5d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='post-26']/div/table[2]/tbody/tr[17]/td[2]/strong</value>
      <webElementGuid>c823b830-42d8-4a8f-9509-8b535f781038</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Safai Sevak'])[3]/following::strong[1]</value>
      <webElementGuid>96dfd495-741f-45ab-9796-d9f5f117efc0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='P. DANAPANDI'])[1]/following::strong[1]</value>
      <webElementGuid>5026b7d7-c45d-44a8-b927-e0888774fedf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Safai Sevak'])[4]/preceding::strong[1]</value>
      <webElementGuid>f6d47740-e9fd-44cc-bbf0-a2cd8e56c6bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search for:'])[1]/preceding::strong[1]</value>
      <webElementGuid>73a0050f-2f7b-45a0-ba5b-8305c043f39e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='M. MUTHU KANNAN']/parent::*</value>
      <webElementGuid>2c5e8559-3bff-40ff-96f7-4ed9ae7bc0fd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[17]/td[2]/strong</value>
      <webElementGuid>df2324ef-6d7e-4e3d-8f60-2e160f8516c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//strong[(text() = 'M. MUTHU KANNAN' or . = 'M. MUTHU KANNAN')]</value>
      <webElementGuid>8de26780-7ce5-4f98-90d0-f3c9d1739286</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
