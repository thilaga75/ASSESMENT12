<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_To propgate the Gandhian messege of Tr_37fe4a</name>
   <tag></tag>
   <elementGuidId>3cfc31ea-f17a-48f7-9b10-342029aa5d9d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p:nth-of-type(2) > strong > span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='post-26']/div/p[2]/strong/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;To propgate the Gandhian messege of Truth and Nonvilolence and give specific tra&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>244db27e-9073-4181-b4f2-f784608b5ebc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>To propgate the Gandhian messege of Truth and Nonvilolence and give specific training with skills upgradation for relevant individuals, groups and communities.</value>
      <webElementGuid>d6791068-6526-4c22-89c6-4180e53b35d0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;post-26&quot;)/div[@class=&quot;storycontent&quot;]/p[2]/strong[1]/span[1]</value>
      <webElementGuid>04433e5e-93d3-449b-aee2-af3f12223a1d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='post-26']/div/p[2]/strong/span</value>
      <webElementGuid>ad771d78-f02c-49c9-a4e2-dccbd8731fe5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mission'])[1]/following::span[1]</value>
      <webElementGuid>af0c10ec-92f7-4c07-b080-f6b3112e0a47</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About us'])[2]/following::span[3]</value>
      <webElementGuid>0274a918-2419-43dd-b64a-df3b333d20a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Objectives'])[1]/preceding::span[1]</value>
      <webElementGuid>097e0009-f36c-40d5-9879-45c1afe09446</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Governance'])[1]/preceding::span[4]</value>
      <webElementGuid>d7593445-694d-435b-b248-7a6efcb1ee4b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='To propgate the Gandhian messege of Truth and Nonvilolence and give specific training with skills upgradation for relevant individuals, groups and communities.']/parent::*</value>
      <webElementGuid>81a739da-1843-424d-bd62-407b6cd48bd6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[2]/strong/span</value>
      <webElementGuid>c5035681-d58c-40af-91ce-0121706f948b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'To propgate the Gandhian messege of Truth and Nonvilolence and give specific training with skills upgradation for relevant individuals, groups and communities.' or . = 'To propgate the Gandhian messege of Truth and Nonvilolence and give specific training with skills upgradation for relevant individuals, groups and communities.')]</value>
      <webElementGuid>72b2c2e0-5979-4637-997c-7cd8c6591e21</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
