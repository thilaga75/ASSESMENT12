<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>strong_SECRETARY, Dept. of Culture, New Del_71b4b4</name>
   <tag></tag>
   <elementGuidId>992ca74c-45ea-4c4f-a7e3-a207adaa7dc1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p:nth-of-type(6) > strong</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='post-26']/div/table/tbody/tr[10]/td/p[6]/strong</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;SECRETARY, Dept. of Culture, New Delhi. (Ex-Officio Member)&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>strong</value>
      <webElementGuid>d3747938-c037-4c02-bbb8-25768621a196</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>SECRETARY, Dept. of Culture, New Delhi. (Ex-Officio Member)</value>
      <webElementGuid>99be2d57-8781-498f-ad05-de814b6b375d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;post-26&quot;)/div[@class=&quot;storycontent&quot;]/table[1]/tbody[1]/tr[10]/td[1]/p[6]/strong[1]</value>
      <webElementGuid>e76e4fac-eca8-4bc7-b67f-e882fc981817</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='post-26']/div/table/tbody/tr[10]/td/p[6]/strong</value>
      <webElementGuid>0ec33d8b-f736-47ad-aa87-36956350e994</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shri. N. Ramalingam.'])[1]/following::strong[1]</value>
      <webElementGuid>a0ae0f89-bf83-435c-b275-8250d70fd630</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shri T.S.R. Venkatramana'])[1]/following::strong[2]</value>
      <webElementGuid>3a74112e-4721-48f1-8509-ee4d0fb513cf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SECRETARY Dept. of Tourism and Culture Tamil Nadu (Ex-Officio Member)'])[1]/preceding::strong[1]</value>
      <webElementGuid>390aa73f-f216-4948-a9ea-f08a476917c3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='STAFF'])[1]/preceding::strong[2]</value>
      <webElementGuid>df4e7593-f110-4adf-ae6c-ebd9732fbb63</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='SECRETARY, Dept. of Culture, New Delhi. (Ex-Officio Member)']/parent::*</value>
      <webElementGuid>f46a07e3-e035-42c3-a672-a4e32cccf269</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[6]/strong</value>
      <webElementGuid>1f60c78c-441e-48fb-a78a-7004b4cbd237</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//strong[(text() = 'SECRETARY, Dept. of Culture, New Delhi. (Ex-Officio Member)' or . = 'SECRETARY, Dept. of Culture, New Delhi. (Ex-Officio Member)')]</value>
      <webElementGuid>f5a8a16e-271a-49c4-a907-4a2a59b1f4e7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
