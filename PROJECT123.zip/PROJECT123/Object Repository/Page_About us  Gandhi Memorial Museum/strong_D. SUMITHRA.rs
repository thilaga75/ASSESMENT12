<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>strong_D. SUMITHRA</name>
   <tag></tag>
   <elementGuidId>95c7cd7c-0c0f-483c-af89-c4094f97756f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>td:nth-of-type(3) > strong</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='post-26']/div/table[2]/tbody/tr[3]/td[3]/strong</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;D. SUMITHRA&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>strong</value>
      <webElementGuid>65381672-663c-403b-826f-f4fc1b499824</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>D. SUMITHRA</value>
      <webElementGuid>821af5fc-79a7-44cb-84fa-208e5f6be8ff</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;post-26&quot;)/div[@class=&quot;storycontent&quot;]/table[2]/tbody[1]/tr[3]/td[3]/strong[1]</value>
      <webElementGuid>d6ac8e6c-df88-47df-a732-73839182bd35</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='post-26']/div/table[2]/tbody/tr[3]/td[3]/strong</value>
      <webElementGuid>20e5843a-b449-47ec-a924-e54934e2d50d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Curator i/c. / Education Officer / P.I.O.'])[1]/following::strong[1]</value>
      <webElementGuid>0e4e9753-3108-4a16-8007-610fa02485c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mr.R. Natarajan'])[1]/following::strong[1]</value>
      <webElementGuid>986b6b17-abe1-4477-b711-5e5a39c43d28</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Accountant'])[1]/preceding::strong[1]</value>
      <webElementGuid>2b24817b-ee9d-492a-8639-276858338df7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='S. SABURA BIBI'])[1]/preceding::strong[1]</value>
      <webElementGuid>e83896fa-8b27-4c51-89ae-bf5116540afe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='D. SUMITHRA']/parent::*</value>
      <webElementGuid>444549bf-1cd4-4e86-b3c7-16dd25bde782</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td[3]/strong</value>
      <webElementGuid>cb731ed1-eeef-47e5-819f-c65ea397e782</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//strong[(text() = 'D. SUMITHRA' or . = 'D. SUMITHRA')]</value>
      <webElementGuid>3b869513-d63b-4add-9a5f-75388bbd8100</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
