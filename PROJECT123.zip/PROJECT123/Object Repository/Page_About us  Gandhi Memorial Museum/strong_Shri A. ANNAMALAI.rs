<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>strong_Shri A. ANNAMALAI</name>
   <tag></tag>
   <elementGuidId>cd41bd36-c621-48b6-88d2-922f5c7e6f56</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p:nth-of-type(2) > strong:nth-of-type(2)</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='post-26']/div/table/tbody/tr[10]/td/p[2]/strong[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Shri A. ANNAMALAI&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>strong</value>
      <webElementGuid>67392462-bbb0-45f3-9dd4-697f6d448859</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Shri A. ANNAMALAI </value>
      <webElementGuid>20a7bf91-1b56-4c93-816a-042074f201f4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;post-26&quot;)/div[@class=&quot;storycontent&quot;]/table[1]/tbody[1]/tr[10]/td[1]/p[2]/strong[2]</value>
      <webElementGuid>a00051f1-1a7c-47fc-8732-e11c3bbbd048</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='post-26']/div/table/tbody/tr[10]/td/p[2]/strong[2]</value>
      <webElementGuid>1e705a63-9b75-4f86-8b7b-b8331eb7e345</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='D. BALASUNDARAM,'])[1]/following::strong[2]</value>
      <webElementGuid>ec682898-74ed-4ded-818d-258ff263b9b0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shri. K. HARI THIAGARAJAN,'])[1]/preceding::strong[1]</value>
      <webElementGuid>81f26b18-ca4b-4334-a070-689a1539eead</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shri T.S.R. Venkatramana'])[1]/preceding::strong[2]</value>
      <webElementGuid>081f2b7f-e4f4-4d81-bcaf-469db586c1bc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Shri A. ANNAMALAI']/parent::*</value>
      <webElementGuid>35059997-f821-4de1-90d2-f2549c18e8f0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[2]/strong[2]</value>
      <webElementGuid>91f37f63-7c47-4b35-81cf-1765d3745f93</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//strong[(text() = 'Shri A. ANNAMALAI ' or . = 'Shri A. ANNAMALAI ')]</value>
      <webElementGuid>2d16808f-4504-4cc0-8272-082b2f50f208</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
