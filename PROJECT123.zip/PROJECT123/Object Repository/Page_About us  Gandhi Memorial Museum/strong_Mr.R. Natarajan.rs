<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>strong_Mr.R. Natarajan</name>
   <tag></tag>
   <elementGuidId>61aa1c10-1617-4ff6-aefd-51d24b20e3fe</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>table:nth-of-type(2) > tbody > tr:nth-of-type(3) > td > strong</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='post-26']/div/table[2]/tbody/tr[3]/td/strong</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Mr.R. Natarajan&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>strong</value>
      <webElementGuid>0de90adc-e7fd-4e16-9f71-e54a8225a8d5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Mr.R. Natarajan</value>
      <webElementGuid>b4974284-a0c7-46d2-8e06-550375e96244</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;post-26&quot;)/div[@class=&quot;storycontent&quot;]/table[2]/tbody[1]/tr[3]/td[1]/strong[1]</value>
      <webElementGuid>a8ff488a-8c27-4d1f-b289-8257adf11b8b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='post-26']/div/table[2]/tbody/tr[3]/td/strong</value>
      <webElementGuid>f8a31512-bc67-4088-a87f-210b999ec70d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='OFFICE'])[1]/following::strong[1]</value>
      <webElementGuid>b0aca005-2d87-44b7-be54-8a2502b22c4b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='MUSEUM'])[1]/following::strong[2]</value>
      <webElementGuid>48b9f7d3-d6f1-4591-8c10-59ba76427273</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Curator i/c. / Education Officer / P.I.O.'])[1]/preceding::strong[1]</value>
      <webElementGuid>24f2f6bf-0395-4ad3-976d-f5b908fc11a6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='D. SUMITHRA'])[1]/preceding::strong[1]</value>
      <webElementGuid>0dbe92ed-dbdc-4ffb-863b-095f7ddeb7b7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Mr.R. Natarajan']/parent::*</value>
      <webElementGuid>57d43fc3-7817-42ce-80bb-2b87ceb6bac9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//table[2]/tbody/tr[3]/td/strong</value>
      <webElementGuid>eb9335db-cb2d-4269-a0d0-8f1f535273ab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//strong[(text() = 'Mr.R. Natarajan' or . = 'Mr.R. Natarajan')]</value>
      <webElementGuid>61251fce-fb58-4f8c-a6d2-3f1a2a669ddb</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
