<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>strong_SECRETARY Dept. of Tourism and Cultu_830ac2</name>
   <tag></tag>
   <elementGuidId>08e53fb3-5c1c-4a91-9770-552ce6d76a6e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p:nth-of-type(7) > strong</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='post-26']/div/table/tbody/tr[10]/td/p[7]/strong</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;SECRETARY Dept. of Tourism and Culture Tamil Nadu (Ex-Officio Member)&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>strong</value>
      <webElementGuid>4350104f-383a-49a9-99dd-369c2ae5ff38</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>SECRETARY Dept. of Tourism and Culture Tamil Nadu (Ex-Officio Member)</value>
      <webElementGuid>c24682b8-4431-4f7b-80f0-4e89b58b99dc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;post-26&quot;)/div[@class=&quot;storycontent&quot;]/table[1]/tbody[1]/tr[10]/td[1]/p[7]/strong[1]</value>
      <webElementGuid>c8a1337d-def2-426d-8c30-a37f895005c5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='post-26']/div/table/tbody/tr[10]/td/p[7]/strong</value>
      <webElementGuid>52c86433-dc10-423c-a448-c5ea2f22e2c0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SECRETARY, Dept. of Culture, New Delhi. (Ex-Officio Member)'])[1]/following::strong[1]</value>
      <webElementGuid>c90635d1-64de-428d-9a61-e3431cab6b3b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shri. N. Ramalingam.'])[1]/following::strong[2]</value>
      <webElementGuid>4fe7ec62-1092-430a-a40c-6fb994a82d3b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='STAFF'])[1]/preceding::strong[1]</value>
      <webElementGuid>7d9cdc74-26f0-4107-8ca3-cf9413c54c06</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='MUSEUM'])[1]/preceding::strong[2]</value>
      <webElementGuid>d61f385d-9406-44fe-ad87-6937557b61f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='SECRETARY Dept. of Tourism and Culture Tamil Nadu (Ex-Officio Member)']/parent::*</value>
      <webElementGuid>fcff6e83-c986-4cbd-913c-0f229e768e97</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[7]/strong</value>
      <webElementGuid>016a113d-c917-4a2b-b04c-fb03b02d3352</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//strong[(text() = 'SECRETARY Dept. of Tourism and Culture Tamil Nadu (Ex-Officio Member)' or . = 'SECRETARY Dept. of Tourism and Culture Tamil Nadu (Ex-Officio Member)')]</value>
      <webElementGuid>9b9c2da4-98e4-41e0-8193-1aae2c7a69f8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
