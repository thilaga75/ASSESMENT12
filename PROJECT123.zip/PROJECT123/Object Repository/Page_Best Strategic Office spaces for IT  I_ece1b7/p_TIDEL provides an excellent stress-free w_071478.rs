<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_TIDEL provides an excellent stress-free w_071478</name>
   <tag></tag>
   <elementGuidId>b29b8f1f-cfd0-4010-80bd-9da39ac983e6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.testimonial-item.text-left.en.slick-slide.slick-active > p</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Chief Executive Officer, Pointel Solutions (I) Pvt. Ltd.'])[1]/following::p[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;TIDEL provides an excellent stress-free work environment with a full security ch&quot;i >> nth=1</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>34ea1b3c-3a3e-4d19-b4a0-4e23eb102858</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>TIDEL provides an excellent stress-free work environment with a full security check. Employees feel safe and good environment to work with. Tidel team provides amazing end-to-end support makes us feel very comfortable and offers the best office space at affordable prices.</value>
      <webElementGuid>64dc3377-a027-4c38-a36b-fc9ebdc54651</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/div[@class=&quot;tidel-testimonial-area gray-bg pt-100 pb-60 fix&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-12 offset-xl-0 mb-30&quot;]/div[@class=&quot;testimonia-item-active test-3-dot slick-initialized slick-slider&quot;]/div[@class=&quot;slick-list draggable&quot;]/div[@class=&quot;slick-track&quot;]/div[@class=&quot;testimonial-item text-left en slick-slide slick-active&quot;]/p[1]</value>
      <webElementGuid>9db5f6c3-3ebb-420a-b05c-4d33d288c592</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Chief Executive Officer, Pointel Solutions (I) Pvt. Ltd.'])[1]/following::p[1]</value>
      <webElementGuid>e21eef54-9088-4398-80cf-f8ade1d1e461</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Saraswathy K.'])[1]/following::p[1]</value>
      <webElementGuid>f0016212-7b6d-4a4f-815c-96366c925284</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kalyan'])[2]/preceding::p[1]</value>
      <webElementGuid>1971426c-b879-4a41-b492-0c4d5adcc4bc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Greenbooks'])[2]/preceding::p[1]</value>
      <webElementGuid>d5883600-980c-46e6-8cee-1b3769319daa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[6]/p</value>
      <webElementGuid>c9ff55ae-6c39-41fe-aaaf-416991711fd8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'TIDEL provides an excellent stress-free work environment with a full security check. Employees feel safe and good environment to work with. Tidel team provides amazing end-to-end support makes us feel very comfortable and offers the best office space at affordable prices.' or . = 'TIDEL provides an excellent stress-free work environment with a full security check. Employees feel safe and good environment to work with. Tidel team provides amazing end-to-end support makes us feel very comfortable and offers the best office space at affordable prices.')]</value>
      <webElementGuid>f3fc3cf1-e498-47dc-aff4-f4a0d617180e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
