<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Chief Executive Officer, Pointel Solut_0cdfcf</name>
   <tag></tag>
   <elementGuidId>14fbb4bd-f474-4794-93df-772eeee347b8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.testimonial-item.text-left.en.slick-slide.slick-current.slick-active > div.designation.mb-30 > span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Saraswathy K.'])[1]/following::span[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Chief Executive Officer, Pointel Solutions (I) Pvt. Ltd.&quot;i >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>e9712ebd-ddc9-43bd-8260-e185e526af2f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Chief Executive Officer, Pointel Solutions (I) Pvt. Ltd.</value>
      <webElementGuid>2d80529a-cc5e-4994-abf4-5ef28830d96b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/div[@class=&quot;tidel-testimonial-area gray-bg pt-100 pb-60 fix&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-12 offset-xl-0 mb-30&quot;]/div[@class=&quot;testimonia-item-active test-3-dot slick-initialized slick-slider&quot;]/div[@class=&quot;slick-list draggable&quot;]/div[@class=&quot;slick-track&quot;]/div[@class=&quot;testimonial-item text-left en slick-slide slick-current slick-active&quot;]/div[@class=&quot;designation mb-30&quot;]/span[1]</value>
      <webElementGuid>edcaac8a-c0d0-4361-a6f0-3292d8769fd3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Saraswathy K.'])[1]/following::span[1]</value>
      <webElementGuid>dc58e88d-7a6f-4c58-abe6-b666c37ead3e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CEO, Guardian India Operations Pvt. Ltd.'])[1]/following::span[1]</value>
      <webElementGuid>c2d41c18-212c-4b6a-bcb4-1c72a481d3f7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kalyan'])[2]/preceding::span[1]</value>
      <webElementGuid>941c94da-9c2c-418e-8abc-7608995bd5af</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Greenbooks'])[2]/preceding::span[1]</value>
      <webElementGuid>3cc03db6-ae33-47dc-867b-09dcaf7d2b3f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Chief Executive Officer, Pointel Solutions (I) Pvt. Ltd.']/parent::*</value>
      <webElementGuid>76a6d421-0914-4fab-a822-edafa62469ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/span</value>
      <webElementGuid>41bf1af6-d67f-4297-807c-3fa2fc45a62a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Chief Executive Officer, Pointel Solutions (I) Pvt. Ltd.' or . = 'Chief Executive Officer, Pointel Solutions (I) Pvt. Ltd.')]</value>
      <webElementGuid>6fcf0fe2-c657-441c-8b76-ac1dfe6894d6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
