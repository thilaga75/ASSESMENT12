<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Latest at TIDEL                        _4fb7c2</name>
   <tag></tag>
   <elementGuidId>8f3e8a3b-fc5d-4cca-980d-f1d38fce060d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.col-xl-5.col-lg-5.col-md-6.titdelfeature</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Find Space'])[2]/following::div[5]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Latest at TIDEL All things and everything TIDEL: fromopportunities to events. Ex&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>390b30fe-3170-4ee5-b28e-493a7d68654b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-xl-5 col-lg-5 col-md-6 titdelfeature</value>
      <webElementGuid>97a9274c-2175-4345-909c-364a3e625a82</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

                    

                        Latest at TIDEL 

                    

                    All things and everything TIDEL: fromopportunities to events. Explore more to find out. 

                </value>
      <webElementGuid>d0ce9963-5d83-4c3b-82a8-6fa965db27f4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/div[@class=&quot;feature-area pb-30 pt-60&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-5 col-lg-5 col-md-6 titdelfeature&quot;]</value>
      <webElementGuid>033b0e69-5156-4b7c-ad9d-2be680806a75</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Find Space'])[2]/following::div[5]</value>
      <webElementGuid>7d4e1ffe-b77c-4d60-9e37-e7764e48bd0e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Move Forward'])[1]/following::div[5]</value>
      <webElementGuid>007a3633-5309-42a4-90c4-1ab613d95c11</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//main/div/div/div/div</value>
      <webElementGuid>47045218-0a17-46ab-8d63-abadda533799</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '

                    

                        Latest at TIDEL 

                    

                    All things and everything TIDEL: fromopportunities to events. Explore more to find out. 

                ' or . = '

                    

                        Latest at TIDEL 

                    

                    All things and everything TIDEL: fromopportunities to events. Explore more to find out. 

                ')]</value>
      <webElementGuid>0983574a-6902-4373-9ec8-925c098cb7a5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
