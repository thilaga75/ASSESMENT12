<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Sep 02, 2022</name>
   <tag></tag>
   <elementGuidId>bc6007bc-18c2-4d30-8cd4-c596a263fc3b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#slick-slide31 > div.blog-wrapper.mb-30 > div.blog-img > div.blog-date</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='slick-slide31']/div/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Sep 02, 2022&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>4d612f7f-c3ae-4366-8e72-f228c40a9480</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>blog-date</value>
      <webElementGuid>3b7fd4d0-ed79-4625-9c01-c793ad288128</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Sep 02, 2022</value>
      <webElementGuid>0e0adccb-3949-4ba5-bb58-5272eb21019a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;slick-slide31&quot;)/div[@class=&quot;blog-wrapper mb-30&quot;]/div[@class=&quot;blog-img&quot;]/div[@class=&quot;blog-date&quot;]</value>
      <webElementGuid>e4ae03ea-77f4-4f17-a999-0d8363ad2fd3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='slick-slide31']/div/div/div</value>
      <webElementGuid>df6c7fe7-6ed5-49a1-aaa1-248df15982a6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Read More'])[1]/following::div[4]</value>
      <webElementGuid>035d5e48-c7b6-4281-90bc-ac2d9c964af4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='TIDEL Neo - Villupuram'])[1]/following::div[4]</value>
      <webElementGuid>2f2ef362-8213-4532-b68e-f96065f2a1a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='TIDEL Park - Pattabiram'])[1]/preceding::div[1]</value>
      <webElementGuid>baf3b738-824d-4eea-b933-4cdc200a034b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Read More'])[2]/preceding::div[1]</value>
      <webElementGuid>547a331f-fccb-4790-984c-18866439f742</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Sep 02, 2022']/parent::*</value>
      <webElementGuid>c6e8c87c-169d-461d-9d86-2c71d4f4320f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div[2]/div/div/div</value>
      <webElementGuid>8672522e-0ac0-42bb-b69a-8613e6424e6d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Sep 02, 2022' or . = 'Sep 02, 2022')]</value>
      <webElementGuid>e199dda1-2450-47a5-b468-b95fb38703c7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
