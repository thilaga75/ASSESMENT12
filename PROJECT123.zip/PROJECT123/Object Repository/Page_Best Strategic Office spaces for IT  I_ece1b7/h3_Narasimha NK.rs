<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h3_Narasimha NK</name>
   <tag></tag>
   <elementGuidId>dffaf9e6-d53f-40c3-bc90-044846503b15</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.testimonial-item.text-left.en.slick-slide.slick-current.slick-active > div.designation.mb-30 > h3</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='.'])[2]/following::h3[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Narasimha NK&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
      <webElementGuid>2a2208d2-0505-435c-bbc4-7cd7609f372c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Narasimha NK</value>
      <webElementGuid>07ec5c60-47f0-4f5c-8df5-2d942881f9fd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/div[@class=&quot;tidel-testimonial-area gray-bg pt-100 pb-60 fix&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-12 offset-xl-0 mb-30&quot;]/div[@class=&quot;testimonia-item-active test-3-dot slick-initialized slick-slider&quot;]/div[@class=&quot;slick-list draggable&quot;]/div[@class=&quot;slick-track&quot;]/div[@class=&quot;testimonial-item text-left en slick-slide slick-current slick-active&quot;]/div[@class=&quot;designation mb-30&quot;]/h3[1]</value>
      <webElementGuid>0b241ee0-5612-4017-9165-38de9d34b75c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='.'])[2]/following::h3[1]</value>
      <webElementGuid>b0a7cd78-e1cd-4f28-a7df-44755e006c0b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Greenbooks'])[2]/following::h3[1]</value>
      <webElementGuid>417dc524-fb36-4a68-8ed0-57bd583863e1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Director, Miramed Ajuba Solutions Pvt. Ltd.'])[2]/preceding::h3[1]</value>
      <webElementGuid>020442e2-eb9b-4a35-afa4-5a5441b3af7b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shanker'])[2]/preceding::h3[1]</value>
      <webElementGuid>a839b0b4-d67f-478e-80a5-389641d71906</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div/h3</value>
      <webElementGuid>121914fa-0184-4cef-abc0-8fd33b2778ce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h3[(text() = 'Narasimha NK' or . = 'Narasimha NK')]</value>
      <webElementGuid>cef1e068-adea-4803-b878-e24a0f10f8e3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
