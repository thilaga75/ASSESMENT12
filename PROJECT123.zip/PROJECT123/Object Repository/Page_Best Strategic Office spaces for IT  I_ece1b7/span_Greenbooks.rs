<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Greenbooks</name>
   <tag></tag>
   <elementGuidId>a34ddc28-1416-41aa-901f-bf3a01b49d06</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Kalyan'])[2]/following::span[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Greenbooks&quot;i >> nth=1</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>e19062d4-9ca9-40c2-8be1-27137419fa7d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Greenbooks</value>
      <webElementGuid>1227cebb-165a-4624-806e-87c7b8e3ed64</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/div[@class=&quot;tidel-testimonial-area gray-bg pt-100 pb-60 fix&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-12 offset-xl-0 mb-30&quot;]/div[@class=&quot;testimonia-item-active test-3-dot slick-initialized slick-slider&quot;]/div[@class=&quot;slick-list draggable&quot;]/div[@class=&quot;slick-track&quot;]/div[@class=&quot;testimonial-item text-left en slick-slide slick-active&quot;]/div[@class=&quot;designation mb-30&quot;]/span[1]</value>
      <webElementGuid>2f269c94-d124-4c33-ac6e-99f7a19572b1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kalyan'])[2]/following::span[1]</value>
      <webElementGuid>14831195-0e40-4194-9721-b4d8e8cba893</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Chief Executive Officer, Pointel Solutions (I) Pvt. Ltd.'])[1]/following::span[1]</value>
      <webElementGuid>0930d2ce-c607-4293-8432-12d44572e28d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='.'])[2]/preceding::span[1]</value>
      <webElementGuid>a05d687c-1038-4f62-9075-cb5890b24dd1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Narasimha NK'])[2]/preceding::span[1]</value>
      <webElementGuid>55f4dd06-a5f7-41b8-a9bf-3cbfeb29a1c4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[6]/div/span</value>
      <webElementGuid>477984ec-79f5-4d2a-b423-00de1a4c4832</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Greenbooks' or . = 'Greenbooks')]</value>
      <webElementGuid>14cc776d-af6d-49b7-a510-a128f1521b79</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
