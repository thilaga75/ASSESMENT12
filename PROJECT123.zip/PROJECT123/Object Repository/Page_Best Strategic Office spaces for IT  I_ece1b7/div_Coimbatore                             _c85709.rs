<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Coimbatore                             _c85709</name>
   <tag></tag>
   <elementGuidId>3a4be3eb-fba5-40fe-8b71-2965fa9f33bd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Locations'])[1]/following::div[8]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Coimbatore TIDEL goes beyond Chennai, spreading opportunities and growth to peop&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>df8e9ea7-914d-4ffc-9a61-095731a43284</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>tidel-services-content</value>
      <webElementGuid>bbccb768-117e-4f56-bd88-88285146ca06</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

                            Coimbatore  

                            TIDEL goes beyond Chennai, spreading opportunities and growth to people across the state.
                        </value>
      <webElementGuid>81d65a9d-844d-4f28-ae5f-69a9d02eafd4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/div[@class=&quot;services-area pt-60 pb-30&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-4 col-lg-4 col-md-6&quot;]/div[@class=&quot;tidel-services tidel-services-02 mb-30&quot;]/div[@class=&quot;tidel-services-content&quot;]</value>
      <webElementGuid>6d26ebab-b294-40e0-ae63-d59168a5dc5e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Locations'])[1]/following::div[8]</value>
      <webElementGuid>a8d5962b-227b-40a8-9f99-f867507ce2be</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='TIDEL goes beyond Chennai, spreading opportunities and growth to people across the state.']/parent::*</value>
      <webElementGuid>65923752-765e-4ffa-b212-f99ed954bf58</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div[2]</value>
      <webElementGuid>a272c359-a870-4997-853d-47089b787ce4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '

                            Coimbatore  

                            TIDEL goes beyond Chennai, spreading opportunities and growth to people across the state.
                        ' or . = '

                            Coimbatore  

                            TIDEL goes beyond Chennai, spreading opportunities and growth to people across the state.
                        ')]</value>
      <webElementGuid>fc2af9a5-ec98-4a35-b79b-cc4d1a7fecb0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
