<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Choose Building                     _1a704d</name>
   <tag></tag>
   <elementGuidId>c9a679ea-ef10-48fd-b87f-171b8e344d1f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#building</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='building']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#building</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>20e947ad-ae31-4639-be87-2adefa78bf42</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>building</value>
      <webElementGuid>ced7f21b-de85-4d9b-af08-c7b2ccee7c61</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>selectarrow</value>
      <webElementGuid>881e41c8-da8d-445d-ac6e-3a04e894a3e3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>options</value>
      <webElementGuid>8437a1f2-32b4-4912-95fa-721c9825f973</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

                            Choose Building

                            Taramani

                            Pattabiram

                            Coimbatore

                       

                        </value>
      <webElementGuid>e6ec84cc-99c2-4eab-b7dd-c603c95990c1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;building&quot;)</value>
      <webElementGuid>9650fd80-bd04-4e31-99ff-f577c09f5bd8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='building']</value>
      <webElementGuid>3dbecdaa-f9fa-4c14-83ee-1c745d7d860b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Find Space'])[3]/following::select[2]</value>
      <webElementGuid>99284a6d-f5a6-406d-aa7b-ecf03da6faa5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enquiry'])[4]/preceding::select[2]</value>
      <webElementGuid>ff617977-efa6-40d4-9b2c-a5acb7d1040a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Testimonials'])[2]/preceding::select[2]</value>
      <webElementGuid>016eaddc-60e4-42f3-a1c1-9904110684d6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]/label/select</value>
      <webElementGuid>edf560df-c08d-439b-b6a2-cae0abbf57d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@id = 'building' and @name = 'options' and (text() = '

                            Choose Building

                            Taramani

                            Pattabiram

                            Coimbatore

                       

                        ' or . = '

                            Choose Building

                            Taramani

                            Pattabiram

                            Coimbatore

                       

                        ')]</value>
      <webElementGuid>d0d1d890-e95a-4f70-8a71-9f0285df1149</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
