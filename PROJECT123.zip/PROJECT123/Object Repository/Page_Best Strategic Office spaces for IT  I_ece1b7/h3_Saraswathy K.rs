<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h3_Saraswathy K</name>
   <tag></tag>
   <elementGuidId>da546611-3500-4928-af03-e470f687837e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.testimonial-item.text-left.en.slick-slide.slick-current.slick-active > div.designation.mb-30 > h3</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='CEO, Guardian India Operations Pvt. Ltd.'])[1]/following::h3[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Saraswathy K.&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
      <webElementGuid>f7eb7630-a7a2-4da8-96ae-8e0f36b1127b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Saraswathy K.</value>
      <webElementGuid>6b8aec91-3351-4fc7-9b43-9087c7c4019f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/div[@class=&quot;tidel-testimonial-area gray-bg pt-100 pb-60 fix&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-12 offset-xl-0 mb-30&quot;]/div[@class=&quot;testimonia-item-active test-3-dot slick-initialized slick-slider&quot;]/div[@class=&quot;slick-list draggable&quot;]/div[@class=&quot;slick-track&quot;]/div[@class=&quot;testimonial-item text-left en slick-slide slick-current slick-active&quot;]/div[@class=&quot;designation mb-30&quot;]/h3[1]</value>
      <webElementGuid>cfa9fcab-7744-45eb-bc0e-898d82054cbf</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CEO, Guardian India Operations Pvt. Ltd.'])[1]/following::h3[1]</value>
      <webElementGuid>d30efc8d-b6a5-46af-aeb6-9fee03905f7e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ajay Jain'])[1]/following::h3[1]</value>
      <webElementGuid>b87149a6-dd60-4557-ba0b-45ebf0b7135b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Chief Executive Officer, Pointel Solutions (I) Pvt. Ltd.'])[1]/preceding::h3[1]</value>
      <webElementGuid>2e000fa9-8cad-4c45-b737-c1e1385ec189</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kalyan'])[2]/preceding::h3[1]</value>
      <webElementGuid>eba2e752-756d-432c-9158-678f5fea4cea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Saraswathy K.']/parent::*</value>
      <webElementGuid>98285088-8df5-4494-a585-b3768932a63d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/h3</value>
      <webElementGuid>5584a944-10fa-4554-8fc9-02ec2d1ac424</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h3[(text() = 'Saraswathy K.' or . = 'Saraswathy K.')]</value>
      <webElementGuid>0947b63f-28cc-4705-ac4e-7d50379d818a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
