<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_First hand experiences from the best orga_9c083a</name>
   <tag></tag>
   <elementGuidId>7e0aac84-6d24-4df2-8792-008a392587e8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.section-title.text-center.mb-15.mpt-30 > p.text-center</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Testimonials'])[2]/following::p[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;First hand experiences from the best organizations in the world.&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>910f665d-3c07-4006-8aa1-3b80e55f3e6d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text-center</value>
      <webElementGuid>caf05e07-6553-4c5f-9098-6316819fec79</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

                            First hand experiences from the best organizations in the world.
                        </value>
      <webElementGuid>081c07a7-ac07-498f-8c9b-6034156c0983</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/div[@class=&quot;tidel-testimonial-area gray-bg pt-100 pb-60 fix&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-6 col-lg-6 offset-lg-3 offset-xl-3&quot;]/div[@class=&quot;section-title text-center mb-15 mpt-30&quot;]/p[@class=&quot;text-center&quot;]</value>
      <webElementGuid>78f837ac-2fc6-475e-ac30-3af8e0514f32</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Testimonials'])[2]/following::p[1]</value>
      <webElementGuid>64b4faa7-7bdb-4ba8-993d-d9eadb7e5871</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enquiry'])[4]/following::p[1]</value>
      <webElementGuid>557d0ff1-e56c-44ff-b4ba-e2c1953837da</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kalyan'])[1]/preceding::p[2]</value>
      <webElementGuid>96d2b3fd-beb5-439e-af68-db3d771f2795</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Greenbooks'])[1]/preceding::p[2]</value>
      <webElementGuid>475caef6-6e31-4df8-ae81-e13862b1942c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='First hand experiences from the best organizations in the world.']/parent::*</value>
      <webElementGuid>fc70967e-56c5-4f9b-a76e-9253b99bfa75</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/div/div/div/p</value>
      <webElementGuid>93ad3914-1f2b-45a7-a7c6-2c246cd95b7c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = '

                            First hand experiences from the best organizations in the world.
                        ' or . = '

                            First hand experiences from the best organizations in the world.
                        ')]</value>
      <webElementGuid>d918b6e5-1930-4292-b9bc-bcf6164d035e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
