<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Testimonials</name>
   <tag></tag>
   <elementGuidId>7bb113da-b059-4f38-b606-e4cbb4bb4b8b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.section-title.text-center.mb-15.mpt-30 > h1</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Enquiry'])[4]/following::h1[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Testimonials&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>23a963ea-a43f-484a-856e-632d43de89fa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Testimonials</value>
      <webElementGuid>e11c9747-cc21-4d5b-a256-d4a3178c400c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/div[@class=&quot;tidel-testimonial-area gray-bg pt-100 pb-60 fix&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-6 col-lg-6 offset-lg-3 offset-xl-3&quot;]/div[@class=&quot;section-title text-center mb-15 mpt-30&quot;]/h1[1]</value>
      <webElementGuid>6e016732-1953-4736-92a3-bcaa640289ab</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enquiry'])[4]/following::h1[1]</value>
      <webElementGuid>216e2fa3-bece-488f-a2d3-7e667be1452e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Find Space'])[3]/following::h1[1]</value>
      <webElementGuid>254da720-95eb-4bfc-9e2c-a354bc58b3d9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kalyan'])[1]/preceding::h1[1]</value>
      <webElementGuid>85599913-7210-4a4f-9bba-27ea1fbb7add</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Greenbooks'])[1]/preceding::h1[1]</value>
      <webElementGuid>a78b61d7-4d65-446c-ad1d-86b9bef75e06</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/div/div/div/h1</value>
      <webElementGuid>7c955bda-ecfd-4816-9098-19270076a306</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = ' Testimonials' or . = ' Testimonials')]</value>
      <webElementGuid>55b12811-e6c7-4e6b-84d2-dc17d48e3b3f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
