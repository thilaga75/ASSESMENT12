<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_SEE MORE</name>
   <tag></tag>
   <elementGuidId>f3444bbf-c933-4f4e-bd23-e57999ad0a85</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.col-xl-12.col-lg-12.col-md-12.pt-30 > div.text-center > a.tidel-btn > span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Director, Miramed Ajuba Solutions Pvt. Ltd.'])[3]/following::span[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;SEE MORE&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>b57fa261-47af-4eea-9256-96506fba77bc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> SEE MORE</value>
      <webElementGuid>4fa42942-65ca-4a84-bdf9-a4be0cac991e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/div[@class=&quot;tidel-testimonial-area gray-bg pt-100 pb-60 fix&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-12 col-lg-12 col-md-12 pt-30&quot;]/div[@class=&quot;text-center&quot;]/a[@class=&quot;tidel-btn&quot;]/span[1]</value>
      <webElementGuid>55b0462b-04e9-4183-87fd-97e2ce48ef69</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Director, Miramed Ajuba Solutions Pvt. Ltd.'])[3]/following::span[1]</value>
      <webElementGuid>b9507b5c-86e8-408b-a34a-ebc423f8d61b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Narasimha NK'])[3]/following::span[2]</value>
      <webElementGuid>bd823f26-5adf-4d6b-9f6b-613ced5c9413</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='TIDEL'])[1]/preceding::span[1]</value>
      <webElementGuid>32a19bfc-bb5f-4bd0-9a6a-684b42053301</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='SEE MORE']/parent::*</value>
      <webElementGuid>ae375704-c8c0-4457-8af0-88577033bea3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/a/span</value>
      <webElementGuid>6efa4fe7-0114-4933-9e5e-8bb1e9dd0738</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = ' SEE MORE' or . = ' SEE MORE')]</value>
      <webElementGuid>269ceb86-321d-4802-a35d-11af52cac14d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
