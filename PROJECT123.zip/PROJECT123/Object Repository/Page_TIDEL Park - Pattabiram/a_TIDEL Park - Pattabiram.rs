<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_TIDEL Park - Pattabiram</name>
   <tag></tag>
   <elementGuidId>37df73a6-4995-401c-a746-43bdc8da3b2a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h4 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'TIDEL Park - Pattabiram')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>h4 >> internal:text=&quot;TIDEL Park - Pattabiram&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>7cf6ecd9-b26d-4eac-8cdd-4390985ff057</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>TIDEL Park - Pattabiram </value>
      <webElementGuid>0c8528d7-4677-4fa3-8484-4bc70ad32c0a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/div[@class=&quot;blog- pb-60 pt-40&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-8 col-lg-8 col-md-8&quot;]/div[@class=&quot;blog-wrapper mb-30&quot;]/div[@class=&quot;blog-text text-left&quot;]/h4[1]/a[1]</value>
      <webElementGuid>3cbe4f98-cdc7-4b49-ad79-9892425c1b33</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'TIDEL Park - Pattabiram')]</value>
      <webElementGuid>dd22701e-74d2-49e1-b1d9-839d4a603a04</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='The Essential Guide'])[1]/following::a[2]</value>
      <webElementGuid>7d620d20-171f-4c8b-8565-c15fe16fb6ce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h4/a</value>
      <webElementGuid>402702e1-61d1-4ec3-b531-f67267c7cf42</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[(text() = 'TIDEL Park - Pattabiram ' or . = 'TIDEL Park - Pattabiram ')]</value>
      <webElementGuid>94731f7b-4baf-48a5-afe2-af7ac019b865</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
