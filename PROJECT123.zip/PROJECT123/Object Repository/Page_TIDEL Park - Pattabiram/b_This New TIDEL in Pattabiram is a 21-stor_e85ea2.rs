<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>b_This New TIDEL in Pattabiram is a 21-stor_e85ea2</name>
   <tag></tag>
   <elementGuidId>ceb0b423-70dd-4c2a-acad-cfd9369d9dda</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p:nth-of-type(4) > #docs-internal-guid-9741620a-7fff-58f2-7f3d-7028ab08746a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//b[@id='docs-internal-guid-9741620a-7fff-58f2-7f3d-7028ab08746a'])[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;This New TIDEL in Pattabiram is a 21-storey facility with salient amenities like&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>b</value>
      <webElementGuid>f64ae5f9-6dd9-41ae-9a47-17b6a879e036</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>docs-internal-guid-9741620a-7fff-58f2-7f3d-7028ab08746a</value>
      <webElementGuid>c230e3af-67a2-4c1b-8e58-f4bca410e1dd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>This New TIDEL in Pattabiram is a 21-storey facility with salient amenities like state-of-the-art Sky Garden, Co-working spaces, and Business Centres.</value>
      <webElementGuid>15166e37-df2a-46fb-bb45-7d37e17a1c9d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/div[@class=&quot;blog- pb-60 pt-40&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-8 col-lg-8 col-md-8&quot;]/div[@class=&quot;blog-wrapper mb-30&quot;]/div[@class=&quot;blog-text text-left&quot;]/p[4]/b[@id=&quot;docs-internal-guid-9741620a-7fff-58f2-7f3d-7028ab08746a&quot;]</value>
      <webElementGuid>e3b60981-b89d-47ef-a4de-083b9c3fdb23</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>(//b[@id='docs-internal-guid-9741620a-7fff-58f2-7f3d-7028ab08746a'])[4]</value>
      <webElementGuid>8a32044e-1055-48d4-b084-ae06f1ab87c9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='TIDEL Pattabiram'])[1]/following::b[3]</value>
      <webElementGuid>af99985c-cbe9-4fb8-96ec-428546333823</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Post Comment:'])[1]/preceding::b[3]</value>
      <webElementGuid>e8bc691f-2792-49df-87f9-cc82ba3b1d22</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Name:'])[1]/preceding::b[3]</value>
      <webElementGuid>1cd21bd7-b017-4d35-ba34-022f90f8ba8b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='This New TIDEL in Pattabiram is a 21-storey facility with salient amenities like state-of-the-art Sky Garden, Co-working spaces, and Business Centres.']/parent::*</value>
      <webElementGuid>a1237e9a-93b4-46e5-996c-cd36c512ad6e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[4]/b</value>
      <webElementGuid>2945df2c-bcab-4e06-b2f0-a83dcbe1d7dc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//b[@id = 'docs-internal-guid-9741620a-7fff-58f2-7f3d-7028ab08746a' and (text() = 'This New TIDEL in Pattabiram is a 21-storey facility with salient amenities like state-of-the-art Sky Garden, Co-working spaces, and Business Centres.' or . = 'This New TIDEL in Pattabiram is a 21-storey facility with salient amenities like state-of-the-art Sky Garden, Co-working spaces, and Business Centres.')]</value>
      <webElementGuid>e149135d-4af4-46b6-8611-68bcad2e5510</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
