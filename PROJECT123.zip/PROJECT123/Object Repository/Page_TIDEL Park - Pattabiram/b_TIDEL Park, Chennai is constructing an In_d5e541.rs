<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>b_TIDEL Park, Chennai is constructing an In_d5e541</name>
   <tag></tag>
   <elementGuidId>a71140a4-dd74-46ad-9924-bbc21413c81d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p:nth-of-type(2) > #docs-internal-guid-9741620a-7fff-58f2-7f3d-7028ab08746a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//b[@id='docs-internal-guid-9741620a-7fff-58f2-7f3d-7028ab08746a'])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;TIDEL Park, Chennai is constructing an Information Technology Park with built up&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>b</value>
      <webElementGuid>15e08dc3-1061-4528-b4e9-46b03fa09269</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>docs-internal-guid-9741620a-7fff-58f2-7f3d-7028ab08746a</value>
      <webElementGuid>8a3c04ed-f4ab-4a0d-bfb2-e2964dd81feb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>TIDEL Park, Chennai is constructing an Information Technology Park with built up space of 5.57lakh sq. ft in an area of 11.41 acres of land in pattabiram village, Avadi Taluk at a cost of Rs.278.84 crore. Construction work is underway and expected to be completed in 2023.</value>
      <webElementGuid>2b12ef42-f5ad-47df-b2a0-98233e004655</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/div[@class=&quot;blog- pb-60 pt-40&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-8 col-lg-8 col-md-8&quot;]/div[@class=&quot;blog-wrapper mb-30&quot;]/div[@class=&quot;blog-text text-left&quot;]/p[2]/b[@id=&quot;docs-internal-guid-9741620a-7fff-58f2-7f3d-7028ab08746a&quot;]</value>
      <webElementGuid>946b31e9-ccb5-4ac1-8ad8-7c3574648510</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>(//b[@id='docs-internal-guid-9741620a-7fff-58f2-7f3d-7028ab08746a'])[2]</value>
      <webElementGuid>d7ca80ae-db18-4ebd-9e09-1cc299784365</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='TIDEL Pattabiram'])[1]/following::b[1]</value>
      <webElementGuid>0fa809a6-aed0-4568-87e1-e25bc3eb66a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Post Comment:'])[1]/preceding::b[5]</value>
      <webElementGuid>6b9e7ed3-2e9c-400a-9105-78b6d9442be3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Name:'])[1]/preceding::b[5]</value>
      <webElementGuid>99c73193-f722-45b3-ab7f-e7495a8edde4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='TIDEL Park, Chennai is constructing an Information Technology Park with built up space of 5.57lakh sq. ft in an area of 11.41 acres of land in pattabiram village, Avadi Taluk at a cost of Rs.278.84 crore. Construction work is underway and expected to be completed in 2023.']/parent::*</value>
      <webElementGuid>2f774dea-3e81-4b57-b435-346133a44817</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[2]/b</value>
      <webElementGuid>2de9a77a-f3e8-4868-a89a-b6d4fe83dfe7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//b[@id = 'docs-internal-guid-9741620a-7fff-58f2-7f3d-7028ab08746a' and (text() = 'TIDEL Park, Chennai is constructing an Information Technology Park with built up space of 5.57lakh sq. ft in an area of 11.41 acres of land in pattabiram village, Avadi Taluk at a cost of Rs.278.84 crore. Construction work is underway and expected to be completed in 2023.' or . = 'TIDEL Park, Chennai is constructing an Information Technology Park with built up space of 5.57lakh sq. ft in an area of 11.41 acres of land in pattabiram village, Avadi Taluk at a cost of Rs.278.84 crore. Construction work is underway and expected to be completed in 2023.')]</value>
      <webElementGuid>fb2a39c3-3201-47d5-9b03-a95a9d8f1b39</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
