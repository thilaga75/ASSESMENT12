<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Board of Directors</name>
   <tag></tag>
   <elementGuidId>b2ff9f5c-799a-4e94-ba39-559fb1766cae</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.footer-link.blog > ul > li:nth-of-type(3) > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//a[contains(text(),'Board of Directors')])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Board of Directors&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>31c3b2c5-ef80-4413-9659-b404784bc09a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/en/about-us#director</value>
      <webElementGuid>b59544ea-49b0-4b6c-aa3a-a259c03937a6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Board of Directors</value>
      <webElementGuid>fad663c0-da56-425e-b88b-19d616c00a9a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/footer[@class=&quot;deskfooter&quot;]/div[@class=&quot;footer-widget-area pt-0 pb-30&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-2 col-lg-2 col-md-6 blog&quot;]/div[@class=&quot;footer-wrapper pl-0 mb-30&quot;]/div[@class=&quot;footer-link blog&quot;]/ul[1]/li[3]/a[1]</value>
      <webElementGuid>ca679615-113a-4cdc-8471-e0ac3672114b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Board of Directors')])[2]</value>
      <webElementGuid>671e9261-ae17-4544-8987-260dc691e12f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='History'])[1]/following::a[1]</value>
      <webElementGuid>c56c4176-c86a-4bbd-b967-09c58315b84c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Vision'])[1]/following::a[2]</value>
      <webElementGuid>3a4e51f6-98ee-4351-88c8-d5aaffc1ea80</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shareholders'])[1]/preceding::a[1]</value>
      <webElementGuid>5472190b-9187-4cd3-95a5-facdfb008da4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Other Ventures'])[1]/preceding::a[2]</value>
      <webElementGuid>88db0fb2-6331-475d-b240-d015106cf81b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '/en/about-us#director')])[2]</value>
      <webElementGuid>878c7f20-d528-46ab-ac61-054b0d8601ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/ul/li[3]/a</value>
      <webElementGuid>1ac2b586-1f03-44f9-abc5-57da6fdf35e4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/en/about-us#director' and (text() = 'Board of Directors' or . = 'Board of Directors')]</value>
      <webElementGuid>69b74b8a-404d-4fe8-9a93-be35dfc129f3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
