<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h3_About Us</name>
   <tag></tag>
   <elementGuidId>77b68030-4c9f-4f46-aa9b-f81965a7efc9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h3.footer-title.blog</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='SUBMIT'])[1]/following::h3[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;About Us&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
      <webElementGuid>66c7f7d1-3866-456d-b2c5-2059b0997ba8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>footer-title blog</value>
      <webElementGuid>0499cf51-424b-4e3a-b00c-e9ede69e8a9f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>About Us</value>
      <webElementGuid>31099e61-5c4b-4447-ad5e-6d922eb03348</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/footer[@class=&quot;deskfooter&quot;]/div[@class=&quot;footer-widget-area pt-0 pb-30&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-2 col-lg-2 col-md-6 blog&quot;]/div[@class=&quot;footer-wrapper pl-0 mb-30&quot;]/h3[@class=&quot;footer-title blog&quot;]</value>
      <webElementGuid>9829ae39-3b79-4b7e-94b6-09486df12621</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SUBMIT'])[1]/following::h3[1]</value>
      <webElementGuid>cd9bfcb1-f14c-401a-980a-af5a299a6620</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Subscribe Now to Our Newsletter'])[1]/following::h3[1]</value>
      <webElementGuid>013d1f55-9a30-4131-a74f-37e470484541</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Vision'])[1]/preceding::h3[1]</value>
      <webElementGuid>a112e8f8-e482-4c0e-91a5-a2f974803077</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='History'])[1]/preceding::h3[1]</value>
      <webElementGuid>63474ec7-8ca6-4d8c-8c73-c9470639b143</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/h3</value>
      <webElementGuid>6c1ee545-9650-4106-aa43-de34c1426690</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h3[(text() = 'About Us' or . = 'About Us')]</value>
      <webElementGuid>3118c7ca-87c6-4d5e-996a-7164c6b6cda9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
