<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_TIDEL is establishing an Information Tech_ce33bb</name>
   <tag></tag>
   <elementGuidId>ec61a4d8-0e39-4803-bd37-df77ab2365f4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p:nth-of-type(3)</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='TIDEL Pattabiram'])[1]/following::p[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>p >> internal:has-text=&quot;TIDEL is establishing an Information Technology (IT) Park (TIDEL Pattabiram) in &quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>b6a1d989-57c9-45e0-8608-8fc5c684d8a9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>dir</name>
      <type>Main</type>
      <value>ltr</value>
      <webElementGuid>0e00e4d2-51bd-4606-9d42-90a1b68074fa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>TIDEL is establishing an Information Technology (IT) Park (TIDEL Pattabiram) in Pattabiram village, Avadi with a view to improve the IT infrastructure in the North Western part of Chennai City.</value>
      <webElementGuid>06197c54-8a4b-40ea-822c-ff94426761b5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/div[@class=&quot;blog- pb-60 pt-40&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-8 col-lg-8 col-md-8&quot;]/div[@class=&quot;blog-wrapper mb-30&quot;]/div[@class=&quot;blog-text text-left&quot;]/p[3]</value>
      <webElementGuid>9d3490f2-64fb-492d-b759-2f0825beadb7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='TIDEL Pattabiram'])[1]/following::p[3]</value>
      <webElementGuid>0515d97d-241b-43c2-9810-5369e9c6141f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Post Comment:'])[1]/preceding::p[4]</value>
      <webElementGuid>e397f3fb-a0fe-41af-80c4-987134b97939</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Name:'])[1]/preceding::p[4]</value>
      <webElementGuid>8241280e-1d1a-4991-b56f-28d0fe586a19</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[3]</value>
      <webElementGuid>c7b02ce5-3c99-4489-88cd-b7224610bbc3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'TIDEL is establishing an Information Technology (IT) Park (TIDEL Pattabiram) in Pattabiram village, Avadi with a view to improve the IT infrastructure in the North Western part of Chennai City.' or . = 'TIDEL is establishing an Information Technology (IT) Park (TIDEL Pattabiram) in Pattabiram village, Avadi with a view to improve the IT infrastructure in the North Western part of Chennai City.')]</value>
      <webElementGuid>ac0b4a23-396f-4b8d-818e-157b166d1843</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
