<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_The Essential Guide</name>
   <tag></tag>
   <elementGuidId>e8bc59cc-f7ec-47cb-a0a4-271f42afd280</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h1 > span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Key Contacts'])[2]/following::span[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;The Essential Guide&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>73e88e36-ff7c-4b99-9da1-bd8b9f66ccf9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>The Essential Guide</value>
      <webElementGuid>8d01929b-8dbe-45b8-bd70-e32f9f9d7962</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/section[@class=&quot;banner&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;caption&quot;]/h1[1]/span[1]</value>
      <webElementGuid>e8e37a56-7198-4d74-9809-4105b9e49df2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Key Contacts'])[2]/following::span[1]</value>
      <webElementGuid>4a3debb4-00d0-49e0-a5f5-24a57f936c71</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='TIDEL Park - Pattabiram'])[2]/preceding::span[2]</value>
      <webElementGuid>529fbcbd-1beb-4fe3-b3c2-8e1975baff4b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='The Essential Guide']/parent::*</value>
      <webElementGuid>884795af-3d78-4796-9765-0c287f76eaf4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1/span</value>
      <webElementGuid>ff236113-d1f0-4362-ab8c-5cbc79d4c56c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'The Essential Guide' or . = 'The Essential Guide')]</value>
      <webElementGuid>c128518b-7f43-4ec7-b1bf-4ae74e2b922b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
