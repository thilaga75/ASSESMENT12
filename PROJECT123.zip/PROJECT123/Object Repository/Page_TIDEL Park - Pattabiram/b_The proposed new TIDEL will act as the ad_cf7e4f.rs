<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>b_The proposed new TIDEL will act as the ad_cf7e4f</name>
   <tag></tag>
   <elementGuidId>8108a6fb-e096-4e94-9148-a95788f8594a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p:nth-of-type(5) > #docs-internal-guid-9741620a-7fff-58f2-7f3d-7028ab08746a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//b[@id='docs-internal-guid-9741620a-7fff-58f2-7f3d-7028ab08746a'])[5]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;The proposed new TIDEL will act as the address for start-ups, and enterprises in&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>b</value>
      <webElementGuid>2f81b7f4-2971-4fda-abfb-56b80dffddba</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>docs-internal-guid-9741620a-7fff-58f2-7f3d-7028ab08746a</value>
      <webElementGuid>78f0f4e8-98d9-4007-ad5d-de14de3f223b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>The proposed new TIDEL will act as the address for start-ups, and enterprises in the IT/ITeS sector with the potential of providing employment to more than 5000 people in its first phase.</value>
      <webElementGuid>e2d87258-0dd9-4b16-8dcc-e620c9e28355</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/div[@class=&quot;blog- pb-60 pt-40&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-8 col-lg-8 col-md-8&quot;]/div[@class=&quot;blog-wrapper mb-30&quot;]/div[@class=&quot;blog-text text-left&quot;]/p[5]/b[@id=&quot;docs-internal-guid-9741620a-7fff-58f2-7f3d-7028ab08746a&quot;]</value>
      <webElementGuid>02ec9fc9-7075-4e7b-8c93-9d70ba9ae07b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>(//b[@id='docs-internal-guid-9741620a-7fff-58f2-7f3d-7028ab08746a'])[5]</value>
      <webElementGuid>0123d33d-142e-463f-bfc4-d8d121781ed4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='TIDEL Pattabiram'])[1]/following::b[4]</value>
      <webElementGuid>cebceb2b-a80d-43b2-8def-e5d8a06a94ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Post Comment:'])[1]/preceding::b[2]</value>
      <webElementGuid>c5fe026d-4ea6-4f3c-8356-0cf7e789bc42</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Name:'])[1]/preceding::b[2]</value>
      <webElementGuid>ff5f955a-9750-404c-9bbb-522361b887e0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='The proposed new TIDEL will act as the address for start-ups, and enterprises in the IT/ITeS sector with the potential of providing employment to more than 5000 people in its first phase.']/parent::*</value>
      <webElementGuid>8dcd6658-6894-4b25-9702-b8c1373375eb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[5]/b</value>
      <webElementGuid>1545867a-2f0f-4ed5-8b15-7a8ec2d64caa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//b[@id = 'docs-internal-guid-9741620a-7fff-58f2-7f3d-7028ab08746a' and (text() = 'The proposed new TIDEL will act as the address for start-ups, and enterprises in the IT/ITeS sector with the potential of providing employment to more than 5000 people in its first phase.' or . = 'The proposed new TIDEL will act as the address for start-ups, and enterprises in the IT/ITeS sector with the potential of providing employment to more than 5000 people in its first phase.')]</value>
      <webElementGuid>1801e526-0090-4cc2-b126-837668af65a3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
