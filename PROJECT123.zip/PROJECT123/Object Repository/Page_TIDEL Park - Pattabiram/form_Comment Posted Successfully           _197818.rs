<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>form_Comment Posted Successfully           _197818</name>
   <tag></tag>
   <elementGuidId>f4b195df-667e-49cc-a64d-3a458055228b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>form.comments-box</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Post Comment:'])[1]/following::form[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Comment Posted Successfully! Name: Email: Comment: Submit&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>form</value>
      <webElementGuid>6c651533-f62c-453e-abf8-7e3ac00f16b7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>method</name>
      <type>Main</type>
      <value>POST</value>
      <webElementGuid>e58f49d9-8f57-45e5-bac9-27d78dd0e1dc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>comments-box</value>
      <webElementGuid>f6015337-551e-41a1-85c4-82ecb9228e30</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                            Comment Posted Successfully!                                            
                                                Name:
                                                
                                            
                                            
                                                Email:
                                                
                                            
                                            
                                                Comment:
                                                
                                            
                                            
                                             Submit
                                            </value>
      <webElementGuid>b9d0a12a-f666-4654-bc2f-e20342bbf6ba</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/div[@class=&quot;blog- pb-60 pt-40&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-8 col-lg-8 col-md-8&quot;]/div[@class=&quot;blog-wrapper mb-30&quot;]/div[@class=&quot;blog-text text-left&quot;]/div[@class=&quot;commets-div&quot;]/form[@class=&quot;comments-box&quot;]</value>
      <webElementGuid>e20fcc85-4483-45f2-a43c-f7cca25eb2c2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Post Comment:'])[1]/following::form[1]</value>
      <webElementGuid>ffb0bf0f-da21-4ba2-8a5c-1202f3b9cf8e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='TIDEL Pattabiram'])[1]/following::form[1]</value>
      <webElementGuid>afabb606-7cff-4276-80d4-17a9db884681</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form</value>
      <webElementGuid>b49cbf11-b445-4b9b-b9c2-4c3451808e1f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//form[(text() = '
                                            Comment Posted Successfully!                                            
                                                Name:
                                                
                                            
                                            
                                                Email:
                                                
                                            
                                            
                                                Comment:
                                                
                                            
                                            
                                             Submit
                                            ' or . = '
                                            Comment Posted Successfully!                                            
                                                Name:
                                                
                                            
                                            
                                                Email:
                                                
                                            
                                            
                                                Comment:
                                                
                                            
                                            
                                             Submit
                                            ')]</value>
      <webElementGuid>018a14e6-b812-426e-9f4f-843a9e64cd93</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
