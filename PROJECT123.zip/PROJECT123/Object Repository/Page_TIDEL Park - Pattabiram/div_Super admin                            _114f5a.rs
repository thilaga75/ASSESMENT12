<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Super admin                            _114f5a</name>
   <tag></tag>
   <elementGuidId>25cd78ac-3e44-465a-8d4c-cac4e9bb2f5e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.blog-meta.pb-20</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='TIDEL Park - Pattabiram'])[2]/following::div[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Super admin September 02, 2022 0 33288&quot;i >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>dd1d2fdc-27a1-41a2-bcc4-16973c84d7d3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>blog-meta pb-20</value>
      <webElementGuid>ea6c5050-9d30-495d-861f-f3e3dcd15d7c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

                                        
                                             Super admin                                        
                                        
                                             September 02, 2022                                        
                                        
                                            0
                                        
                                        
                                             33288
                                        

                                    </value>
      <webElementGuid>f140a591-36eb-4345-a701-cec610838291</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/div[@class=&quot;blog- pb-60 pt-40&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-8 col-lg-8 col-md-8&quot;]/div[@class=&quot;blog-wrapper mb-30&quot;]/div[@class=&quot;blog-text text-left&quot;]/div[@class=&quot;blog-meta pb-20&quot;]</value>
      <webElementGuid>aeb23b9e-7101-455c-bc84-482a0df327ee</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='TIDEL Park - Pattabiram'])[2]/following::div[1]</value>
      <webElementGuid>3c45ddfa-1b23-472d-bc23-53276b38779f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='The Essential Guide'])[1]/following::div[8]</value>
      <webElementGuid>06890bee-b8d6-4db2-9c84-a5effc706d66</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div/div/div[2]/div</value>
      <webElementGuid>5454354e-0f96-4ee5-9996-ff487662acbc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '

                                        
                                             Super admin                                        
                                        
                                             September 02, 2022                                        
                                        
                                            0
                                        
                                        
                                             33288
                                        

                                    ' or . = '

                                        
                                             Super admin                                        
                                        
                                             September 02, 2022                                        
                                        
                                            0
                                        
                                        
                                             33288
                                        

                                    ')]</value>
      <webElementGuid>7a828103-e713-4f81-be50-7caf0cfb5515</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
