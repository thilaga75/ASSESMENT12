<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_September 02, 2022</name>
   <tag></tag>
   <elementGuidId>387a144a-0efc-4987-a1d6-58952f6af830</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span:nth-of-type(2)</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='TIDEL Park - Pattabiram'])[2]/following::span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;September 02, 2022&quot;i >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>5572ca20-cdf9-44b8-af96-414dcf72cf8c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                             September 02, 2022                                        </value>
      <webElementGuid>7e231515-afee-4bfc-aed9-398f2f9b2ddd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/div[@class=&quot;blog- pb-60 pt-40&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-8 col-lg-8 col-md-8&quot;]/div[@class=&quot;blog-wrapper mb-30&quot;]/div[@class=&quot;blog-text text-left&quot;]/div[@class=&quot;blog-meta pb-20&quot;]/span[2]</value>
      <webElementGuid>e9517e0b-86d4-4873-9315-204920524338</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='TIDEL Park - Pattabiram'])[2]/following::span[2]</value>
      <webElementGuid>5de901de-d1de-4875-9165-600c1b57ad39</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='TIDEL Pattabiram'])[1]/preceding::span[3]</value>
      <webElementGuid>c4077ab9-6e65-460c-9dff-c74300586082</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Post Comment:'])[1]/preceding::span[3]</value>
      <webElementGuid>a8b438df-a6b7-4b38-b75a-95875f0188da</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='September 02, 2022']/parent::*</value>
      <webElementGuid>6bc1044a-a06c-4c9d-bd93-cd6ae67de6e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span[2]</value>
      <webElementGuid>c53c74f2-bffd-4f2c-ada0-26016c3059b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
                                             September 02, 2022                                        ' or . = '
                                             September 02, 2022                                        ')]</value>
      <webElementGuid>218285d6-1d93-4697-927a-93986c72b948</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
