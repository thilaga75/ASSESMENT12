<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Interesting tidbits, event highlights, wo_a5d023</name>
   <tag></tag>
   <elementGuidId>e5bc9213-e17f-45d1-aee5-61014f55a6e7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='The Essential Guide'])[1]/following::p[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Interesting tidbits, event highlights, workplace fun and much more that goes on &quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>3147081c-10ff-4985-b803-05915c1c389b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Interesting tidbits, event highlights, workplace fun
                    and much more that goes on here at TIDEL! </value>
      <webElementGuid>14edf1b8-b6c6-4e33-bd7a-8fc14110180a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/section[@class=&quot;banner&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;caption&quot;]/p[1]</value>
      <webElementGuid>85f6dda4-c88f-4bef-96d2-34f35885fb50</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='The Essential Guide'])[1]/following::p[1]</value>
      <webElementGuid>93ce3896-736e-40f3-9b95-93f2ba6552b6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='TIDEL Park - Pattabiram'])[2]/preceding::p[1]</value>
      <webElementGuid>9f91e1ff-ca58-4b73-9123-65330a5ed63b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Interesting tidbits, event highlights, workplace fun']/parent::*</value>
      <webElementGuid>d90cf788-ef67-4a22-9bc8-d1e4321a7ee0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p</value>
      <webElementGuid>d1fb7514-c1cc-48b8-8ba7-caca7b62c822</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Interesting tidbits, event highlights, workplace fun
                    and much more that goes on here at TIDEL! ' or . = 'Interesting tidbits, event highlights, workplace fun
                    and much more that goes on here at TIDEL! ')]</value>
      <webElementGuid>86e7902a-1254-4feb-af17-a2c4a2d75b71</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
