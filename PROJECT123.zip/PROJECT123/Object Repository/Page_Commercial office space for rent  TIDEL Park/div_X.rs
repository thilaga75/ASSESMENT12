<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_X</name>
   <tag></tag>
   <elementGuidId>6257d950-179d-4fce-bfda-df12557bf77e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#myModal</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='myModal']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#myModal</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>87f09fd3-12a4-42aa-8b11-c92af1f8bca0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>modal fade show</value>
      <webElementGuid>6147f4ac-b0ff-47fd-a48b-2481f0a8d50b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>myModal</value>
      <webElementGuid>e2630231-56c1-44f0-833b-6bbaca3bbf21</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>-1</value>
      <webElementGuid>14105acc-36fd-480d-9577-0e9cd71bfa49</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>dialog</value>
      <webElementGuid>d6d6a22a-775b-4ac7-89b3-220eddc402e1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-labelledby</name>
      <type>Main</type>
      <value>exampleModalLabel</value>
      <webElementGuid>e65d252c-d192-4ad7-92fd-c56c645cd9f4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

                        

                            

                                

                                    

                                        X

                                    

                                    

                                        

                                    

                                

                            

                        

                    </value>
      <webElementGuid>8b7446ec-4210-446e-a296-cfbdf77992a4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;myModal&quot;)</value>
      <webElementGuid>01099472-c08a-4474-aabd-8a5dd22e20b1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//div[@id='myModal']</value>
      <webElementGuid>fdc85b03-72c7-4c15-9ec6-dd2562cb4101</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Watch the legacy of'])[1]/following::div[8]</value>
      <webElementGuid>192a2ec6-b013-4eb4-882b-58a4b6633bdf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Vision'])[1]/preceding::div[8]</value>
      <webElementGuid>6b85d24c-c5a7-40a1-9d3a-c87dc362e25b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mission'])[1]/preceding::div[10]</value>
      <webElementGuid>645d4378-71fa-4b9b-ab63-8b4ef054940e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]/div</value>
      <webElementGuid>c04f531f-17bc-4713-8e7c-1d62272e421b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[@id = 'myModal' and (text() = '

                        

                            

                                

                                    

                                        X

                                    

                                    

                                        

                                    

                                

                            

                        

                    ' or . = '

                        

                            

                                

                                    

                                        X

                                    

                                    

                                        

                                    

                                

                            

                        

                    ')]</value>
      <webElementGuid>3db592c5-850c-4559-a669-6b20d5badbfd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
