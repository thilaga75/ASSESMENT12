<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Secretary to Government - Industries Depa_c6898a</name>
   <tag></tag>
   <elementGuidId>a017190d-d504-46ca-a8e3-442d9542e9fe</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.text > p</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='director']/div/div/div[2]/div/div/p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Secretary to Government - Industries Department Chairman&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>ed233fbf-1c59-4964-8f63-54383a3fba09</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Secretary to Government - Industries Department
Chairman</value>
      <webElementGuid>4b1129d8-397b-48a8-b12c-bccdda921cd2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;director&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-3 col-lg-3 col-md-6&quot;]/div[@class=&quot;tidel-direcors mb-30&quot;]/div[@class=&quot;text&quot;]/p[1]</value>
      <webElementGuid>b1c99d03-3ff3-4573-a075-597843c1e85e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='director']/div/div/div[2]/div/div/p</value>
      <webElementGuid>75756cec-d0d3-4cfc-aa42-68f08412a78e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thiru. V. Arun Roy IAS'])[1]/following::p[1]</value>
      <webElementGuid>bdc642aa-4073-4571-b141-09c88e8d43c9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Board of Directors'])[2]/following::p[1]</value>
      <webElementGuid>cc2dcd6c-91ef-4299-b332-43790b5017fb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thiru. Sandeep Nanduri, IAS'])[1]/preceding::p[1]</value>
      <webElementGuid>afbd2aaa-94e9-4082-a3f6-5ed594fe9168</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thiru. Prashant M. Wadnere, IAS'])[1]/preceding::p[2]</value>
      <webElementGuid>641ab1d2-555d-445c-9060-623b5b45d31f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Secretary to Government - Industries Department']/parent::*</value>
      <webElementGuid>50f291ef-12c0-4b0c-94fa-175ad7293778</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/p</value>
      <webElementGuid>31416e0f-e05a-403d-887f-6d962635f93d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Secretary to Government - Industries Department
Chairman' or . = 'Secretary to Government - Industries Department
Chairman')]</value>
      <webElementGuid>122f9c80-c612-4c28-aee4-74208b458884</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
