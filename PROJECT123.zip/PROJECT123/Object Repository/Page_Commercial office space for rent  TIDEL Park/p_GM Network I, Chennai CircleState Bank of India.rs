<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_GM Network I, Chennai CircleState Bank of India</name>
   <tag></tag>
   <elementGuidId>277ed502-e2ce-4de1-a267-c021534ab4e4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='director']/div/div/div[11]/div/div/p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;GM Network I, Chennai CircleState Bank of India&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>5930e9f1-e460-49b4-8d8c-61af0338bde3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>GM Network I, Chennai CircleState Bank of India</value>
      <webElementGuid>a5ffa9c2-c04b-4d08-b8c1-4547f12aa4e4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;director&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-3 col-lg-3 col-md-6&quot;]/div[@class=&quot;tidel-direcors mb-30&quot;]/div[@class=&quot;text&quot;]/p[1]</value>
      <webElementGuid>7ff19a68-1ade-42f1-8ad9-8fd57c5eab4f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='director']/div/div/div[11]/div/div/p</value>
      <webElementGuid>8ed4ee12-9dd5-4bfe-a35e-feb33e0eda6a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thiru. M V R Murali Krishna'])[1]/following::p[1]</value>
      <webElementGuid>70825730-317a-4ef5-a01b-50f295023af7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thiru. Ganda Rajeswara Reddy'])[1]/following::p[2]</value>
      <webElementGuid>e788f857-afc8-4c4f-8cac-f9159b63427b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thiru. Chul Ho Ryu'])[1]/preceding::p[1]</value>
      <webElementGuid>c8145e2e-8767-440a-967a-8193aa401d1e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Subscribe Now to Our Newsletter'])[1]/preceding::p[2]</value>
      <webElementGuid>78f5b496-6eb3-497c-b354-9ac6bc0e266f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='GM Network I, Chennai Circle']/parent::*</value>
      <webElementGuid>aecee9b5-7a0a-4443-88f2-31898d8adf1b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[11]/div/div/p</value>
      <webElementGuid>24227d36-467a-4dff-9fae-100c65776e6a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'GM Network I, Chennai CircleState Bank of India' or . = 'GM Network I, Chennai CircleState Bank of India')]</value>
      <webElementGuid>612de0ae-fa1f-4db2-8107-57ab420ace72</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
