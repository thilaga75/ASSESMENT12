<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Managing DirectorTIDCO  TIDEL</name>
   <tag></tag>
   <elementGuidId>ded67af4-1e0e-4c90-b94c-399f5b7218e9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='director']/div/div/div[3]/div/div/p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Managing Director TIDCO / TIDEL&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>4763f861-86ea-4c26-8588-430e273d4397</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Managing Director
TIDCO / TIDEL </value>
      <webElementGuid>82d8e8ce-3252-4a26-a864-efd2cc551d03</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;director&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-3 col-lg-3 col-md-6&quot;]/div[@class=&quot;tidel-direcors mb-30&quot;]/div[@class=&quot;text&quot;]/p[1]</value>
      <webElementGuid>1a5869e1-d867-4236-bbd1-b021a3f6e660</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='director']/div/div/div[3]/div/div/p</value>
      <webElementGuid>95358eb9-6c94-4503-a0fc-0f58edcd2c53</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thiru. Sandeep Nanduri, IAS'])[1]/following::p[1]</value>
      <webElementGuid>28cae7b3-fdb9-40e7-8e0f-93cb595b8e44</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thiru. V. Arun Roy IAS'])[1]/following::p[2]</value>
      <webElementGuid>847ac9d5-7326-4922-a595-580df771f9cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thiru. Prashant M. Wadnere, IAS'])[1]/preceding::p[1]</value>
      <webElementGuid>fed9ffaa-5d3a-46d4-8665-4f1969f215bf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tmt. Mariam Pallavi Baldev, IAS'])[1]/preceding::p[2]</value>
      <webElementGuid>9e36f49a-d70c-4644-b902-f919297354ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Managing Director']/parent::*</value>
      <webElementGuid>51878914-4111-4899-8059-f3f18976b382</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/p</value>
      <webElementGuid>d39e77db-a28b-453e-92f3-efad9ddfa69d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Managing Director
TIDCO / TIDEL ' or . = 'Managing Director
TIDCO / TIDEL ')]</value>
      <webElementGuid>3fb86d86-d001-4b0c-b0c1-1caffe47c8b5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
