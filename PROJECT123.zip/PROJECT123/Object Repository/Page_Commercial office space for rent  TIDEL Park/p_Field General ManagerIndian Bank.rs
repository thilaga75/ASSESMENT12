<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Field General ManagerIndian Bank</name>
   <tag></tag>
   <elementGuidId>bf2b6793-75b6-4bcd-bd90-b5e2f18f442f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='director']/div/div/div[10]/div/div/p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Field General Manager Indian Bank&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>5a920132-7462-4af3-9b77-74445b7f8757</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Field General Manager
Indian Bank</value>
      <webElementGuid>bd550459-3089-4ab0-85ff-5cf439dcc6f0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;director&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-3 col-lg-3 col-md-6&quot;]/div[@class=&quot;tidel-direcors mb-30&quot;]/div[@class=&quot;text&quot;]/p[1]</value>
      <webElementGuid>e49ebd9f-6c82-4676-9876-1dc13874f88e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='director']/div/div/div[10]/div/div/p</value>
      <webElementGuid>8f728e74-5250-47fa-adc0-648a56724912</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thiru. Ganda Rajeswara Reddy'])[1]/following::p[1]</value>
      <webElementGuid>ac508cf8-bfa5-488a-99d6-d843eb7fa9ad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thiru. J. Chakrapani'])[1]/following::p[2]</value>
      <webElementGuid>67862e8c-d7b8-4e6e-bb91-52a4230eace6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thiru. M V R Murali Krishna'])[1]/preceding::p[1]</value>
      <webElementGuid>2455b65d-98d5-48be-93f8-b00bac24ac4b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thiru. Chul Ho Ryu'])[1]/preceding::p[2]</value>
      <webElementGuid>fc997fbb-044f-4b08-9606-b298f8b96a6c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Field General Manager']/parent::*</value>
      <webElementGuid>a0768784-85b8-4b26-a891-7c2978bb1681</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[10]/div/div/p</value>
      <webElementGuid>f95b2f4d-98b2-4ec2-9d92-0f7cf79c076d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Field General Manager
Indian Bank' or . = 'Field General Manager
Indian Bank')]</value>
      <webElementGuid>18fb93d2-019e-4097-a7ec-1f79809e9037</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
