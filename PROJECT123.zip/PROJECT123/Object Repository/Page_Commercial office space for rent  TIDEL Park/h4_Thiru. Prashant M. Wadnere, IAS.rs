<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h4_Thiru. Prashant M. Wadnere, IAS</name>
   <tag></tag>
   <elementGuidId>15e314e6-47d6-40b1-ada8-7143fff02c65</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='director']/div/div/div[4]/div/div/h4</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Thiru. Prashant M. Wadnere, IAS&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h4</value>
      <webElementGuid>20780e52-9daf-4f0e-8b07-8c3682b8797e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Thiru. Prashant M. Wadnere, IAS</value>
      <webElementGuid>d3204dbf-0003-4799-a915-856e859d2354</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;director&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-3 col-lg-3 col-md-6&quot;]/div[@class=&quot;tidel-direcors mb-30&quot;]/div[@class=&quot;text&quot;]/h4[1]</value>
      <webElementGuid>0a50cb0a-c4b2-4816-89c5-3bd08c8c2d37</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='director']/div/div/div[4]/div/div/h4</value>
      <webElementGuid>1f212301-042e-401d-9c4e-67cc65ed54b9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thiru. Sandeep Nanduri, IAS'])[1]/following::h4[1]</value>
      <webElementGuid>cc8e28d4-ad76-483c-b2fa-96d88ecbea56</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thiru. V. Arun Roy IAS'])[1]/following::h4[2]</value>
      <webElementGuid>651e6613-eb78-4cc8-aff8-b8a63f128de9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tmt. Mariam Pallavi Baldev, IAS'])[1]/preceding::h4[1]</value>
      <webElementGuid>4b4b5c43-7d84-40ba-ae93-124a0fede2a6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dr. S. Christopher'])[1]/preceding::h4[3]</value>
      <webElementGuid>993184af-cac4-49a0-b017-f177aa4a4730</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Thiru. Prashant M. Wadnere, IAS']/parent::*</value>
      <webElementGuid>0c817b7c-d3fb-4675-a484-098e4db279d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div/h4</value>
      <webElementGuid>a77f6c9b-b0c2-479d-82b8-b1cd61763d5b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h4[(text() = 'Thiru. Prashant M. Wadnere, IAS' or . = 'Thiru. Prashant M. Wadnere, IAS')]</value>
      <webElementGuid>7fb17345-535b-49aa-b6ad-6f542ba15b6f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
