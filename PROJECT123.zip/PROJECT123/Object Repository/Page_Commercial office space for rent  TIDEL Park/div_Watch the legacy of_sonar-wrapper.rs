<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Watch the legacy of_sonar-wrapper</name>
   <tag></tag>
   <elementGuidId>46c3ce67-93b8-4cb5-ab20-0cca56312386</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.sonar-wrapper</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Watch the legacy of'])[1]/following::div[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=main >> internal:role=button</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>8647b227-d88e-463d-a2d6-508729691c00</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sonar-wrapper</value>
      <webElementGuid>10e1a955-607b-4881-97e8-415a3c5e3224</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/div[@class=&quot;feature-area en pb-70 pt-100&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-10 col-lg-10 col-md-12&quot;]/p[@class=&quot;pt-30 pl-30 mb-50 pr-20&quot;]/button[@class=&quot;video-btn video-center-btn&quot;]/div[@class=&quot;sonar-wrapper&quot;]</value>
      <webElementGuid>20a0202a-b4c3-4530-995e-59229d4bb1c6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Watch the legacy of'])[1]/following::div[4]</value>
      <webElementGuid>ce65d27f-1d62-4a0d-8e03-d806f5673089</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Vision'])[1]/preceding::div[12]</value>
      <webElementGuid>5aa3acbe-8c16-4e83-83d3-1d1aa82b74cf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mission'])[1]/preceding::div[14]</value>
      <webElementGuid>f5bd2e1f-bfab-4905-80bb-8bbdbe1507de</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button/div</value>
      <webElementGuid>4f4e3d8b-901a-49a0-ad0e-139132842a37</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
