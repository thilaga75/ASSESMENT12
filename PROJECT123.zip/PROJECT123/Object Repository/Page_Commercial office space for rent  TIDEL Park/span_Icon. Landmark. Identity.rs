<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Icon. Landmark. Identity</name>
   <tag></tag>
   <elementGuidId>04a6fd2f-a2ab-448c-94be-707287967edf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h1 > span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Visitor Pass'])[1]/following::span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Icon. Landmark. Identity.&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>399b1649-0173-4774-91c3-d90ca6d951c7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Icon. Landmark. Identity. </value>
      <webElementGuid>fdcc11cd-a1c5-493e-ad06-d9b7a20edcfa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/section[@class=&quot;banner&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;caption&quot;]/span[@class=&quot;middle-align en&quot;]/h1[1]/span[1]</value>
      <webElementGuid>47595432-af05-4e77-af7d-8fd04131cd14</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Visitor Pass'])[1]/following::span[2]</value>
      <webElementGuid>d69d5d8a-0cd2-4b0e-9bb2-de208efd0b5c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Find Space'])[1]/following::span[2]</value>
      <webElementGuid>2d30796e-e210-4db4-93a3-5b93ea1bad07</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Watch the legacy of'])[1]/preceding::span[1]</value>
      <webElementGuid>d746c68f-adca-4ef7-800a-14fd64392aa9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Icon. Landmark. Identity.']/parent::*</value>
      <webElementGuid>51d80be0-7822-4d2f-99d1-0160f97b1f45</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1/span</value>
      <webElementGuid>b41758b1-67a6-44da-8697-caf31e708ec0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Icon. Landmark. Identity. ' or . = 'Icon. Landmark. Identity. ')]</value>
      <webElementGuid>fa24bdb1-1c6c-4285-b0c8-cfa04ad888c9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
