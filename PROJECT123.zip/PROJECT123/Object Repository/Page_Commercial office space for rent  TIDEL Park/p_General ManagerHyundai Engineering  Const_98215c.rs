<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_General ManagerHyundai Engineering  Const_98215c</name>
   <tag></tag>
   <elementGuidId>895b6ad6-5881-4b9c-9426-b00e0c6310b9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='director']/div/div/div[12]/div/div/p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;General Manager Hyundai Engineering &amp; Construction Co. Ltd.&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>62df979d-7ef2-42dc-8785-fe7058ae5835</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>General Manager
Hyundai Engineering &amp; Construction Co. Ltd.</value>
      <webElementGuid>04cedebd-3c18-42b5-962f-6463d6c19035</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;director&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-3 col-lg-3 col-md-6&quot;]/div[@class=&quot;tidel-direcors mb-30&quot;]/div[@class=&quot;text&quot;]/p[1]</value>
      <webElementGuid>d9dc900f-683c-4f3d-9487-0c917393f0aa</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='director']/div/div/div[12]/div/div/p</value>
      <webElementGuid>f089fd52-796f-4e83-aaa1-6f31793e8ffd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thiru. Chul Ho Ryu'])[1]/following::p[1]</value>
      <webElementGuid>013de664-1418-4e45-b523-58e679c99f69</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thiru. M V R Murali Krishna'])[1]/following::p[2]</value>
      <webElementGuid>f9fd0bb0-5ab7-4cf2-b585-af937cd73f7c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Subscribe Now to Our Newsletter'])[1]/preceding::p[1]</value>
      <webElementGuid>f24f06db-123c-46d4-bbdf-f4d4e11a113e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SUBMIT'])[1]/preceding::p[1]</value>
      <webElementGuid>179a1a85-90b6-4ce9-be20-0cd55cf7e2fa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='General Manager']/parent::*</value>
      <webElementGuid>c17f78cb-0c72-470a-83fe-0aa58fded000</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[12]/div/div/p</value>
      <webElementGuid>f534c562-49e0-4e03-899d-82d1b34adbf4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'General Manager
Hyundai Engineering &amp; Construction Co. Ltd.' or . = 'General Manager
Hyundai Engineering &amp; Construction Co. Ltd.')]</value>
      <webElementGuid>4fc2f5ee-1d20-42e8-bb9f-dc8aa6911c16</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
