<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Thiru. V. Arun Roy IAS                 _f644b5</name>
   <tag></tag>
   <elementGuidId>ef647c78-9cf8-43c7-8492-ec61ae774d88</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.text</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='director']/div/div/div[2]/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Thiru. V. Arun Roy IAS Secretary to Government - Industries Department Chairman&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>647f3c20-a1d2-4557-b502-97194cab76e0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text</value>
      <webElementGuid>5f46b939-ca76-43c8-b458-34c19730d60a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

                            Thiru. V. Arun Roy IAS

                            Secretary to Government - Industries Department
Chairman
                        </value>
      <webElementGuid>fb090162-9cee-48ad-bb54-a379a3a61fd4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;director&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-3 col-lg-3 col-md-6&quot;]/div[@class=&quot;tidel-direcors mb-30&quot;]/div[@class=&quot;text&quot;]</value>
      <webElementGuid>5cdc3da1-ff43-47a2-9848-e539421a646a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='director']/div/div/div[2]/div/div</value>
      <webElementGuid>5b90e755-f9cf-46ee-a88d-145b48cfa330</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Board of Directors'])[2]/following::div[3]</value>
      <webElementGuid>d141a70b-49e3-4670-a86f-f05a8d466a1b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='>> Improved customer satisfaction by minimising customer complaints'])[1]/following::div[10]</value>
      <webElementGuid>ec19783a-07bf-42f0-ba25-d14c935fe168</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thiru. Sandeep Nanduri, IAS'])[1]/preceding::div[1]</value>
      <webElementGuid>64642bf1-b120-4ddc-8f4a-edee1be1cbfb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/div/div[2]/div/div</value>
      <webElementGuid>d3b8b1b6-e86c-49c7-a0f7-1f3d391b9f59</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '

                            Thiru. V. Arun Roy IAS

                            Secretary to Government - Industries Department
Chairman
                        ' or . = '

                            Thiru. V. Arun Roy IAS

                            Secretary to Government - Industries Department
Chairman
                        ')]</value>
      <webElementGuid>3e32af72-cc15-473d-b1b8-1b096887e644</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
