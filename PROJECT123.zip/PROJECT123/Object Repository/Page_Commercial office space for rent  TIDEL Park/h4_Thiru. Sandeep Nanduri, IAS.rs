<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h4_Thiru. Sandeep Nanduri, IAS</name>
   <tag></tag>
   <elementGuidId>4ab978df-444b-41d1-8302-99153ac45af8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='director']/div/div/div[3]/div/div/h4</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Thiru. Sandeep Nanduri, IAS&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h4</value>
      <webElementGuid>d797c56f-2c40-4c3e-b64d-3646612ad2f1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Thiru. Sandeep Nanduri, IAS</value>
      <webElementGuid>42926f11-df9c-42a7-9eb6-32630af38cfb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;director&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-3 col-lg-3 col-md-6&quot;]/div[@class=&quot;tidel-direcors mb-30&quot;]/div[@class=&quot;text&quot;]/h4[1]</value>
      <webElementGuid>12f4efa7-7f8d-4492-b444-1106411998f1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='director']/div/div/div[3]/div/div/h4</value>
      <webElementGuid>3401cd1c-ea07-419d-a9b8-5d6817f8ff4b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thiru. V. Arun Roy IAS'])[1]/following::h4[1]</value>
      <webElementGuid>fc668b45-daeb-49f3-b66e-8a68ecf0cc04</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Board of Directors'])[2]/following::h4[2]</value>
      <webElementGuid>0c9460fd-b7c5-45d2-bbc5-ff4fb654d391</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thiru. Prashant M. Wadnere, IAS'])[1]/preceding::h4[1]</value>
      <webElementGuid>c276a90d-90fc-433f-a794-b248c9ea0b08</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tmt. Mariam Pallavi Baldev, IAS'])[1]/preceding::h4[2]</value>
      <webElementGuid>6ba0abf5-b25d-473b-8810-8865a5973033</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Thiru. Sandeep Nanduri, IAS']/parent::*</value>
      <webElementGuid>83c60ea6-c61d-4293-b544-61029a8eeb68</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/h4</value>
      <webElementGuid>02ebbba0-a67b-4966-8190-a1e4b40f29c1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h4[(text() = 'Thiru. Sandeep Nanduri, IAS' or . = 'Thiru. Sandeep Nanduri, IAS')]</value>
      <webElementGuid>e1cbc8da-cc5d-41df-bc79-21a56fb50b8d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
