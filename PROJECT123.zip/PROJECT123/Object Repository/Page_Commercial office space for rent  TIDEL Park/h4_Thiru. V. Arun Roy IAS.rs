<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h4_Thiru. V. Arun Roy IAS</name>
   <tag></tag>
   <elementGuidId>47a3168e-6ab6-4df1-9ed2-70dae090f69c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h4</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='director']/div/div/div[2]/div/div/h4</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Thiru. V. Arun Roy IAS&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h4</value>
      <webElementGuid>00bd4031-78d8-403d-9b3d-7ea4ab62cd03</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Thiru. V. Arun Roy IAS</value>
      <webElementGuid>502b9be4-d756-41f2-82ba-897f32d36425</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;director&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-3 col-lg-3 col-md-6&quot;]/div[@class=&quot;tidel-direcors mb-30&quot;]/div[@class=&quot;text&quot;]/h4[1]</value>
      <webElementGuid>ad65ec64-0d58-416a-a565-c75b4228397c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='director']/div/div/div[2]/div/div/h4</value>
      <webElementGuid>6f59914d-80d1-4142-bd56-9ce927634b56</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Board of Directors'])[2]/following::h4[1]</value>
      <webElementGuid>860b390d-0c15-40c5-a077-a95e43f5e634</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='>> Improved customer satisfaction by minimising customer complaints'])[1]/following::h4[1]</value>
      <webElementGuid>2ecb4282-38b8-4b6d-b29e-edf0c0947e8d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thiru. Sandeep Nanduri, IAS'])[1]/preceding::h4[1]</value>
      <webElementGuid>278e9d6a-0e74-41c8-abcd-32a72a3e189f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thiru. Prashant M. Wadnere, IAS'])[1]/preceding::h4[2]</value>
      <webElementGuid>a08a588c-b528-4e07-9e1e-6443a95e9bfa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Thiru. V. Arun Roy IAS']/parent::*</value>
      <webElementGuid>3d5e3851-cc9f-4a70-9d47-209aba44fb05</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h4</value>
      <webElementGuid>1174c911-5185-4a98-adc5-acc04efd1431</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h4[(text() = 'Thiru. V. Arun Roy IAS' or . = 'Thiru. V. Arun Roy IAS')]</value>
      <webElementGuid>ad1b9012-dcb4-442b-8f9e-2fdaa005ca1e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
