<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Watch the legacy of_col-xl-1 col-lg-1 col-md-1</name>
   <tag></tag>
   <elementGuidId>ae5ee8ad-8c97-4a01-8b94-2de1fd14fcf9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.feature-area.en.pb-70.pt-100 > div.container > div.row > div.col-xl-1.col-lg-1.col-md-1</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//main/div/div/div[2]/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>.container > div:nth-child(2) > div >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>513ba951-dfda-44b6-8446-12079a6beb05</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-xl-1 col-lg-1 col-md-1</value>
      <webElementGuid>5ae194cd-42e2-4abc-a4fa-27776a3a60ed</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/div[@class=&quot;feature-area en pb-70 pt-100&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-1 col-lg-1 col-md-1&quot;]</value>
      <webElementGuid>46a1b6bd-05ad-4d45-8d63-b73ce300656a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//main/div/div/div[2]/div</value>
      <webElementGuid>4e6f556e-2bcf-4762-b1da-1b430c197f68</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
