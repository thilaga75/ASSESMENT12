<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Subscribe Now to Our Newsletter</name>
   <tag></tag>
   <elementGuidId>adffe2f7-7971-4e23-8da6-aa19a34affe4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.widget.en > h1</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='SUBMIT'])[2]/following::h1[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Subscribe Now to Our Newsletter&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>d560dc04-1a10-43d2-87b1-0a4c8955d02b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Subscribe Now to Our Newsletter</value>
      <webElementGuid>88655a83-205c-4b00-ac6a-2585e41cc1ed</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/footer[@class=&quot;deskfooter&quot;]/div[@class=&quot;footer-widget-area pt-0 pb-30&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;subscribe&quot;]/div[@class=&quot;widget en&quot;]/h1[1]</value>
      <webElementGuid>92e78b5a-8b16-4a77-801b-151c9ca5f8f5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SUBMIT'])[2]/following::h1[1]</value>
      <webElementGuid>809402fa-c33c-413e-b27b-81cd91f31933</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Counter'])[2]/following::h1[1]</value>
      <webElementGuid>fcac4c53-60c5-4522-8805-96aa3dc70401</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SUBMIT'])[3]/preceding::h1[1]</value>
      <webElementGuid>ad985285-a974-4ff5-a16d-11f1ba850fd3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About Us'])[1]/preceding::h1[1]</value>
      <webElementGuid>bb230dbd-8d5c-4ebd-bfb3-0cc7424cdb6f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Subscribe Now to Our Newsletter']/parent::*</value>
      <webElementGuid>77a739e8-7954-409d-b751-c5db3f2dca2e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//footer/div/div/div/div/h1</value>
      <webElementGuid>9660deb8-f7fe-49a3-9390-9baf5d12ab18</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = 'Subscribe Now to Our Newsletter' or . = 'Subscribe Now to Our Newsletter')]</value>
      <webElementGuid>d2299a7e-d8ed-4b14-91e2-b244c4e2e14a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
