<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>th_Tender Type</name>
   <tag></tag>
   <elementGuidId>266df51b-1e5f-4021-8e43-9250f0ac7389</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>th:nth-of-type(3)</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Tender Description'])[1]/following::th[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;Tender Type&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>th</value>
      <webElementGuid>72d9e93e-106f-4c6e-941a-7eca8deaad7f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Tender Type</value>
      <webElementGuid>2659dcde-2e79-4847-b37a-2178c2f3dc6e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/div[@class=&quot;feature-area pb-60 pt-60&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row text-center&quot;]/div[@class=&quot;col-xl-12 col-lg-12 col-md-12 col-sm-12 text-center mb-30&quot;]/table[@class=&quot;table table-responsive table-borderless&quot;]/thead[1]/tr[1]/th[3]</value>
      <webElementGuid>3fb87102-d809-4121-b47c-ee25bbff881a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tender Description'])[1]/following::th[1]</value>
      <webElementGuid>fe3bd62d-a58f-40df-9db2-b2919713c328</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tender Number'])[1]/following::th[2]</value>
      <webElementGuid>f6e10fdb-54e5-4739-bc99-9e591dad6463</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Location'])[2]/preceding::th[1]</value>
      <webElementGuid>5f6d3b2d-cfc4-4447-98e6-f85483ccdb79</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Last Date'])[1]/preceding::th[2]</value>
      <webElementGuid>b5ce4502-5c97-4db3-ad69-d359530b2cbb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Tender Type']/parent::*</value>
      <webElementGuid>53bdcc8a-9c77-4209-a9d2-8da6e0765b81</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//th[3]</value>
      <webElementGuid>fab0cd94-1371-421d-940f-3e6aa8a8d502</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//th[(text() = 'Tender Type' or . = 'Tender Type')]</value>
      <webElementGuid>84d3a229-83f0-487d-b969-909a2cf77c23</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
