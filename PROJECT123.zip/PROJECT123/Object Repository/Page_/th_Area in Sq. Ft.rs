<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>th_Area in Sq. Ft</name>
   <tag></tag>
   <elementGuidId>8c006363-0706-4143-8b60-003795e84c7e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='profile']/table[2]/thead/tr/th[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;Area in Sq. Ft.&quot;i] >> nth=1</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>th</value>
      <webElementGuid>920f32d9-b9fa-4002-86fb-b9812fc95769</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Area in Sq. Ft.</value>
      <webElementGuid>9f0d4466-8856-4d76-a2c6-6ba1cf59f3d2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;profile&quot;)/table[@class=&quot;table table-responsive table-borderless&quot;]/thead[1]/tr[1]/th[4]</value>
      <webElementGuid>9aa9cce4-20ec-4dc4-a5de-2b41b0919913</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='profile']/table[2]/thead/tr/th[4]</value>
      <webElementGuid>156b4c27-d0e0-4932-bab8-17d67bbf16a6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Module No'])[2]/following::th[1]</value>
      <webElementGuid>1b592014-22aa-4ffe-85cd-7c9ffdea252e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Counter'])[1]/following::th[2]</value>
      <webElementGuid>2db315f3-3c2b-485f-bff3-440e92356238</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ready for Occupation'])[2]/preceding::th[1]</value>
      <webElementGuid>31e0bc90-6f61-4ae0-91ed-9bd6c0312766</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Floor Status'])[2]/preceding::th[2]</value>
      <webElementGuid>4077421d-8901-4868-a4c0-30c5d8cd4254</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//table[2]/thead/tr/th[4]</value>
      <webElementGuid>96bd6635-5184-4f25-b853-59f6cc1e65b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//th[(text() = 'Area in Sq. Ft.' or . = 'Area in Sq. Ft.')]</value>
      <webElementGuid>cdd6c2e5-10fd-4c13-a317-39090d170293</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
