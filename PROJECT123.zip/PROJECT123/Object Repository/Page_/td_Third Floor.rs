<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_Third Floor</name>
   <tag></tag>
   <elementGuidId>85218914-89e3-4bdf-ade7-df5d35090d04</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='profile']/table/tbody/tr[14]/td</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;Third Floor&quot;i] >> nth=3</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>c6724f91-c2ae-4496-b5b7-c64963f5d0cd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Third Floor</value>
      <webElementGuid>d54ce480-75b2-4235-9ddd-19695d3ecdde</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;profile&quot;)/table[@class=&quot;table table-responsive-sm table-borderless&quot;]/tbody[1]/tr[@class=&quot;white-bg&quot;]/td[1]</value>
      <webElementGuid>c7903673-a0a2-4d09-acd7-c5cb133ab720</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='profile']/table/tbody/tr[14]/td</value>
      <webElementGuid>fc71be48-b451-484f-a3ca-4a3156231ab4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enquire'])[14]/following::td[1]</value>
      <webElementGuid>462eea2a-2e6a-436f-bcd2-e68e0291f3e3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Warm Shell'])[13]/following::td[2]</value>
      <webElementGuid>51d850df-dc46-4204-8d8e-7952a7137384</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='A'])[14]/preceding::td[1]</value>
      <webElementGuid>ea217c0d-3692-40dd-846f-bab438ce52a1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SA-TF-04'])[1]/preceding::td[2]</value>
      <webElementGuid>ec0b8b9a-e7e4-476e-b1f7-77b90eb94100</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[14]/td</value>
      <webElementGuid>b5ba20fd-1117-4d77-906d-c6c31336fa5f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = 'Third Floor' or . = 'Third Floor')]</value>
      <webElementGuid>053f148b-0307-4bcd-8c07-c94ed84626a7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
