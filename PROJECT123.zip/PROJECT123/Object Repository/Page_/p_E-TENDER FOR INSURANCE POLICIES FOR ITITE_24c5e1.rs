<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_E-TENDER FOR INSURANCE POLICIES FOR ITITE_24c5e1</name>
   <tag></tag>
   <elementGuidId>a063f527-a0f8-4903-8d4c-2d6637211e1d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a > p</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Download'])[1]/following::p[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;E-TENDER FOR INSURANCE POLICIES FOR IT/ITES (SEZ) TIDEL PARK AT COIMBATORE&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>aeae944d-de3b-4474-8f83-dabf4781e54c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>E-TENDER FOR INSURANCE POLICIES FOR IT/ITES (SEZ) TIDEL PARK AT COIMBATORE</value>
      <webElementGuid>8464c216-75fe-486c-948f-af439971ee15</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/div[@class=&quot;feature-area pb-60 pt-60&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row text-center&quot;]/div[@class=&quot;col-xl-12 col-lg-12 col-md-12 col-sm-12 text-center mb-30&quot;]/table[@class=&quot;table table-responsive table-borderless&quot;]/tbody[1]/tr[@class=&quot;white-bg&quot;]/td[@class=&quot;text-capitalize&quot;]/a[1]/p[1]</value>
      <webElementGuid>659123ee-aaf0-45c6-b6bb-0dc48c9365b5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download'])[1]/following::p[1]</value>
      <webElementGuid>0e49c2c8-5869-4aed-8dfc-44f7e3783347</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Last Date'])[1]/following::p[1]</value>
      <webElementGuid>bb52960f-5670-4321-a75b-8be334bcbed7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='OPEN'])[1]/preceding::p[1]</value>
      <webElementGuid>7b2027d0-81cb-4a0c-bd4d-87f6708d5e4b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Coimbatore'])[2]/preceding::p[1]</value>
      <webElementGuid>9c4f5290-95a0-44d3-b36d-2c4982477fed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='E-TENDER FOR INSURANCE POLICIES FOR IT/ITES (SEZ) TIDEL PARK AT COIMBATORE']/parent::*</value>
      <webElementGuid>ad4973c7-5b44-4f21-afd7-e588a85a07d3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a/p</value>
      <webElementGuid>8fdad4b9-a6ca-4556-a071-67cad06b5358</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'E-TENDER FOR INSURANCE POLICIES FOR IT/ITES (SEZ) TIDEL PARK AT COIMBATORE' or . = 'E-TENDER FOR INSURANCE POLICIES FOR IT/ITES (SEZ) TIDEL PARK AT COIMBATORE')]</value>
      <webElementGuid>4230b49e-2cb8-4837-bb1e-b01089b4be8f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
