<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>th_Ready for Occupation</name>
   <tag></tag>
   <elementGuidId>26517c2c-39dd-4f9e-8b88-d75447874e9e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='profile']/table[2]/thead/tr/th[5]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;Ready for Occupation&quot;i] >> nth=1</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>th</value>
      <webElementGuid>1f3c6107-ff12-4b9c-8bbb-6cf1fb9a51db</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Ready for Occupation</value>
      <webElementGuid>af1a533a-4e70-4171-96d2-1cc3b7e0a2ca</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;profile&quot;)/table[@class=&quot;table table-responsive table-borderless&quot;]/thead[1]/tr[1]/th[5]</value>
      <webElementGuid>b5bde76c-a099-4bbb-b4d3-a54161bb8500</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='profile']/table[2]/thead/tr/th[5]</value>
      <webElementGuid>cade6758-1e3b-426d-9254-eb20f31904a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Area in Sq. Ft.'])[2]/following::th[1]</value>
      <webElementGuid>a68eb843-cdde-43a7-8b96-46db46459042</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Module No'])[2]/following::th[2]</value>
      <webElementGuid>4241ec5b-e5a6-45f9-8191-4521336407ed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Floor Status'])[2]/preceding::th[1]</value>
      <webElementGuid>2021b858-d65c-4334-b8d1-d969cbf03f01</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enquire'])[2]/preceding::th[2]</value>
      <webElementGuid>397bb896-c5bb-4eb3-8da9-54aa5dd4047f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//table[2]/thead/tr/th[5]</value>
      <webElementGuid>7f208ef7-31fe-4868-b77f-c593251d053f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//th[(text() = 'Ready for Occupation' or . = 'Ready for Occupation')]</value>
      <webElementGuid>75f4c415-733f-4d48-8632-13f7a308445b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
