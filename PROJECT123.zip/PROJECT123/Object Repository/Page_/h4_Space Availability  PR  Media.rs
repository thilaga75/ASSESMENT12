<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h4_Space Availability  PR  Media</name>
   <tag></tag>
   <elementGuidId>b2fda030-fa27-421c-af55-5bf211d9005b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.container > div.row > div.col-xl-4.col-lg-4.col-md-6 > div.tidel-direcors.mb-20 > div.tidel_support_header > h4</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='KEY CONTACTS'])[1]/following::h4[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Space Availability / PR &amp; Media&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h4</value>
      <webElementGuid>3995bcb0-4e4a-4888-b69d-d660b61e1b7c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Space Availability / PR &amp; Media</value>
      <webElementGuid>c545148f-a718-403c-847b-820902892c27</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/div[@class=&quot;services-area pt-100 pb-70&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-4 col-lg-4 col-md-6&quot;]/div[@class=&quot;tidel-direcors mb-20&quot;]/div[@class=&quot;tidel_support_header&quot;]/h4[1]</value>
      <webElementGuid>b9b4120d-ae3e-49bb-a63c-acd963505bc5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='KEY CONTACTS'])[1]/following::h4[1]</value>
      <webElementGuid>e4611f1d-1148-4581-885a-444a266b6c9d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Feedback / Complaints'])[1]/following::h4[1]</value>
      <webElementGuid>8777c433-070f-450b-9e62-6856256aa020</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='M Gita'])[2]/preceding::h4[1]</value>
      <webElementGuid>fda39c03-c999-4ded-8b30-c0acedc71062</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tenders'])[3]/preceding::h4[1]</value>
      <webElementGuid>d14a0608-1759-4df2-b1e3-c4f70755b3e4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Space Availability / PR &amp; Media']/parent::*</value>
      <webElementGuid>7962ae45-a5ec-467f-a9d2-fca132310186</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div[2]/div/div/h4</value>
      <webElementGuid>8565bad0-aa79-48fc-9533-75b1909481f1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h4[(text() = 'Space Availability / PR &amp; Media' or . = 'Space Availability / PR &amp; Media')]</value>
      <webElementGuid>4cda2a9c-aa05-498c-9e4f-a34bb998c1f0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
