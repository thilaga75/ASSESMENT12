<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_For businesses that go places, TIDEL is t_9b7ea7</name>
   <tag></tag>
   <elementGuidId>e3a52507-cd13-4e00-8521-1d1ae1163763</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.middle-align.en > p</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='March Ahead'])[1]/following::p[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;For businesses that go places, TIDEL is the place to be.&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>008b1acb-6e2d-43de-bcf7-17fdb0a7cf11</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>For businesses that go places, TIDEL is the place to be. </value>
      <webElementGuid>41dab6a6-5801-478f-9d5c-e14561675ec4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/section[@class=&quot;banner&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;caption&quot;]/span[@class=&quot;middle-align en&quot;]/p[1]</value>
      <webElementGuid>f6118aa8-3458-427e-adc8-9184990b49d2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='March Ahead'])[1]/following::p[1]</value>
      <webElementGuid>12e4cb7b-1aec-4502-b47f-b0dee553be11</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Visitor Pass'])[1]/following::p[1]</value>
      <webElementGuid>0c71a601-d994-420d-aff6-5c724397116e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='TIDEL that marked a new beginning for Coimbatore.'])[1]/preceding::p[1]</value>
      <webElementGuid>d4bda0f7-752a-4dda-b16f-8460d53f7bab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='TIDEL that marked a new beginning for Coimbatore.'])[2]/preceding::p[2]</value>
      <webElementGuid>4e62012a-b7b8-426d-bdb6-9ae085b4cbbe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='For businesses that go places, TIDEL is the place to be.']/parent::*</value>
      <webElementGuid>bca1710f-63fa-40a9-b1eb-33e2741d0bcf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span/p</value>
      <webElementGuid>299afad3-1fea-40ac-a6df-18473e10316b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'For businesses that go places, TIDEL is the place to be. ' or . = 'For businesses that go places, TIDEL is the place to be. ')]</value>
      <webElementGuid>279f3886-4c93-49c6-bd3d-08b1328ac2a6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
