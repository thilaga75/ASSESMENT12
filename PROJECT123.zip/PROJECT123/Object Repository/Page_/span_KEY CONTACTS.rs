<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_KEY CONTACTS</name>
   <tag></tag>
   <elementGuidId>02d6ddee-1def-481a-aca2-818d3c10cc3c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.col-xl-12.col-lg-12.col-md-12.mb-30.text-center > h1 > span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Feedback / Complaints'])[1]/following::span[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;KEY CONTACTS&quot;s</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>968117f6-1676-4c19-afe4-bf00e9f4bcd7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>KEY CONTACTS</value>
      <webElementGuid>7c4b4f4b-e274-4241-be9e-74b4bc5a6c57</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/div[@class=&quot;services-area pt-100 pb-70&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-12 col-lg-12 col-md-12  mb-30 text-center&quot;]/h1[1]/span[1]</value>
      <webElementGuid>a2268c8a-d323-4a3a-bba2-f5c5e2de1951</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Feedback / Complaints'])[1]/following::span[1]</value>
      <webElementGuid>29b39796-aca6-40e1-8d76-1cac50330bcc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='R Sendhil Murugan'])[1]/following::span[1]</value>
      <webElementGuid>6dda6553-473e-4b59-b0fb-927bad63edf0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Space Availability / PR &amp; Media'])[1]/preceding::span[1]</value>
      <webElementGuid>7a9ada77-003c-4050-a21a-8c46f2019a51</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='M Gita'])[2]/preceding::span[1]</value>
      <webElementGuid>90fe80f7-bd79-4d34-971f-e92233899463</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='KEY CONTACTS']/parent::*</value>
      <webElementGuid>1edaedb3-594d-4b3b-b97e-b6b7a198c462</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/h1/span</value>
      <webElementGuid>a9e9aadd-01cb-440d-80dc-cf7a2526f873</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'KEY CONTACTS' or . = 'KEY CONTACTS')]</value>
      <webElementGuid>f443ab1d-5292-4e3d-8643-f14b3f514e4c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
