<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_March Ahead</name>
   <tag></tag>
   <elementGuidId>aac1f3aa-cda3-4f40-8b65-4e890aa2f542</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h1 > span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Visitor Pass'])[1]/following::span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;March Ahead&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>fe56749e-cfb7-403e-89f8-734fe8488576</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>March Ahead </value>
      <webElementGuid>614b8311-987f-4e2c-8bcf-2a07a2cae1c0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/section[@class=&quot;banner&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;caption&quot;]/span[@class=&quot;middle-align en&quot;]/h1[1]/span[1]</value>
      <webElementGuid>15ffe1f5-c00d-476e-ae52-c031785e6db5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Visitor Pass'])[1]/following::span[2]</value>
      <webElementGuid>67574457-ef43-4b79-a457-d2163dc71268</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Find Space'])[1]/following::span[2]</value>
      <webElementGuid>f05198e3-392c-493a-86e1-9fb27f44903e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='TIDEL that marked a new beginning for Coimbatore.'])[1]/preceding::span[1]</value>
      <webElementGuid>e80a77a1-2096-493b-b508-b57b7aff0803</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='TIDEL that marked a new beginning for Coimbatore.'])[2]/preceding::span[1]</value>
      <webElementGuid>86ce2f20-13f6-4e86-90f4-24fbdb5f696e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='March Ahead']/parent::*</value>
      <webElementGuid>151e01ac-5383-488e-9f6c-a24aa6208770</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1/span</value>
      <webElementGuid>8b909310-cb01-4add-bb25-1311ba7c52e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'March Ahead ' or . = 'March Ahead ')]</value>
      <webElementGuid>ec4b6095-e453-48ed-88f0-b87dca5079fd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
