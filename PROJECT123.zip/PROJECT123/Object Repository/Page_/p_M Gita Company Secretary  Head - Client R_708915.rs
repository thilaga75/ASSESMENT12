<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_M Gita Company Secretary  Head - Client R_708915</name>
   <tag></tag>
   <elementGuidId>eaa31c29-cb19-436c-b0e0-a879fc4676d8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.container > div.row > div.col-xl-4.col-lg-4.col-md-6 > div.tidel-direcors.mb-20 > div.support_box.text > p</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Space Availability / PR &amp; Media'])[1]/following::p[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;M Gita Company Secretary &amp; Head - Client Relations 8754461941 cs@tidelcbe.com / &quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>11c3e6ce-bd2a-48a6-a17d-b67c7a7eb7f0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>M Gita 
Company Secretary &amp; Head - Client Relations
8754461941 
cs@tidelcbe.com / clientrelations@tidelcbe.com</value>
      <webElementGuid>931a0f3d-3122-4453-8345-0de99f9f5a4e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/div[@class=&quot;services-area pt-100 pb-70&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-4 col-lg-4 col-md-6&quot;]/div[@class=&quot;tidel-direcors mb-20&quot;]/div[@class=&quot;support_box text&quot;]/p[1]</value>
      <webElementGuid>f6205a37-12bc-414b-8740-e9e03dad297c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Space Availability / PR &amp; Media'])[1]/following::p[1]</value>
      <webElementGuid>4da4d5f8-bcbc-4fff-a8b7-597660c60c74</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='KEY CONTACTS'])[1]/following::p[1]</value>
      <webElementGuid>12523897-4d46-49d1-a1fd-3a8243db7f08</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tenders'])[3]/preceding::p[1]</value>
      <webElementGuid>e3e993d1-b7e9-4990-b3d5-1c18b6d8e884</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div[2]/div/div[2]/p</value>
      <webElementGuid>796c7776-9cfb-445f-8a3a-40148ebd4053</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'M Gita 
Company Secretary &amp; Head - Client Relations
8754461941 
cs@tidelcbe.com / clientrelations@tidelcbe.com' or . = 'M Gita 
Company Secretary &amp; Head - Client Relations
8754461941 
cs@tidelcbe.com / clientrelations@tidelcbe.com')]</value>
      <webElementGuid>b9e4fe19-0927-4f82-a2a2-ed74d2caacb8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
