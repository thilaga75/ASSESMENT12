<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_R Sendhil MuruganChief Operating Officer9_9d9cc6</name>
   <tag></tag>
   <elementGuidId>24527d4b-d553-45d5-aa16-4889822ab2f4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Tenders'])[3]/following::p[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;R Sendhil Murugan Chief Operating Officer +91 99523 13059 coo@tidelcbe.com&quot;i >> nth=1</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>c9d26a53-f315-4e03-a922-0e00b0193e13</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>R Sendhil Murugan
Chief Operating Officer
+91 99523 13059
coo@tidelcbe.com</value>
      <webElementGuid>7b2b1d94-add6-41d3-86bc-263c9b43dc3d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/main[1]/div[@class=&quot;services-area pt-100 pb-70&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xl-4 col-lg-4 col-md-6&quot;]/div[@class=&quot;tidel-direcors mb-20&quot;]/div[@class=&quot;support_box text&quot;]/p[1]</value>
      <webElementGuid>58b6a52c-72e8-40d2-ae36-84ff64410206</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tenders'])[3]/following::p[1]</value>
      <webElementGuid>150c089f-74bf-4d9d-a306-d1e86c811a46</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='M Gita'])[2]/following::p[1]</value>
      <webElementGuid>f611c549-2f70-4534-a189-0e30af8bc1b9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Finance'])[1]/preceding::p[1]</value>
      <webElementGuid>a615399e-c82c-4235-b810-e2924d86d14b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div[3]/div/div[2]/p</value>
      <webElementGuid>d7a067c0-b572-4d76-b5d9-1b404a5323cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'R Sendhil Murugan
Chief Operating Officer
+91 99523 13059
coo@tidelcbe.com' or . = 'R Sendhil Murugan
Chief Operating Officer
+91 99523 13059
coo@tidelcbe.com')]</value>
      <webElementGuid>61e8be8e-3df8-4a24-ad9c-77e0050b40af</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
