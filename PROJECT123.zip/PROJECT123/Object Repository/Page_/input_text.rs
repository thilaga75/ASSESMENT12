<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>input_text</name>
   <tag></tag>
   <elementGuidId>f7207809-e37f-4e11-9b71-e4c505d88b44</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.widget > div > input[type=&quot;text&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//input[@value='Enter your email id']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=textbox</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>input</value>
      <webElementGuid>3e5fb543-ec20-4688-a06b-0d795bf0dfea</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>text</value>
      <webElementGuid>d2d4682a-966c-4595-a48c-fe8fce802928</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onfocus</name>
      <type>Main</type>
      <value>if (this.value == 'Enter your email id') {this.value='';}</value>
      <webElementGuid>ccbb0172-88ad-4f20-8356-1dcbffe4264e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onblur</name>
      <type>Main</type>
      <value>if (this.value == '') {this.value='Enter your email id';}</value>
      <webElementGuid>db56e510-08d8-4e9b-b00a-c113d311fed2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>value</name>
      <type>Main</type>
      <value>Enter your email id</value>
      <webElementGuid>6bd860a1-e32c-4014-aaeb-1a2bdc483f39</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[1]/footer[@class=&quot;deskfooter&quot;]/div[@class=&quot;footer-widget-area pt-0 pb-30&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;subscribe&quot;]/div[@class=&quot;widget&quot;]/div[1]/input[1]</value>
      <webElementGuid>c2af3525-dd36-4909-b4ce-67df96c98ee9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//input[@value='Enter your email id']</value>
      <webElementGuid>29f99901-0ce9-4d49-b1c0-3767a918e4cc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/input</value>
      <webElementGuid>a6e20904-4f14-4964-9770-9a09a93e9c7a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//input[@type = 'text']</value>
      <webElementGuid>150ecfc1-6913-4ab8-b187-ee26f96590a5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
