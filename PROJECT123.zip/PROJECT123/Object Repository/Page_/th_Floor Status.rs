<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>th_Floor Status</name>
   <tag></tag>
   <elementGuidId>5fe8fcec-d08a-4798-8b30-95884755116d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='profile']/table[2]/thead/tr/th[6]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;Floor Status&quot;i] >> nth=1</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>th</value>
      <webElementGuid>a3f32be5-40be-4e6c-a7bb-08cfc803eef6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Floor Status</value>
      <webElementGuid>704442ee-2009-4c20-a26d-dcd8690e45f8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;profile&quot;)/table[@class=&quot;table table-responsive table-borderless&quot;]/thead[1]/tr[1]/th[6]</value>
      <webElementGuid>95af1906-ca0f-4b77-90cc-008f82818972</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='profile']/table[2]/thead/tr/th[6]</value>
      <webElementGuid>3f356d34-8e1a-4d56-8fd4-a0b9b48ce864</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ready for Occupation'])[2]/following::th[1]</value>
      <webElementGuid>b5e6972d-7e00-4e9b-bb9e-ed0cb6f718ef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Area in Sq. Ft.'])[2]/following::th[2]</value>
      <webElementGuid>160f703c-17c0-45c3-b349-3046a24e0c06</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enquire'])[2]/preceding::th[1]</value>
      <webElementGuid>5f280f65-f6d2-4035-beb7-a5adf8ce6fbc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Application form'])[2]/preceding::th[2]</value>
      <webElementGuid>c6aad017-cd16-4f36-9250-0f2c692635d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//table[2]/thead/tr/th[6]</value>
      <webElementGuid>1264f992-3dba-466c-9574-519cb62ba12c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//th[(text() = 'Floor Status' or . = 'Floor Status')]</value>
      <webElementGuid>efcff38c-8194-44aa-9f52-e57fc9f2dbd5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
