<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>th_Module No</name>
   <tag></tag>
   <elementGuidId>50f1c9c8-11fc-47ea-b2a8-978f57cf84b1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='profile']/table[2]/thead/tr/th[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;Module No&quot;i] >> nth=1</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>th</value>
      <webElementGuid>e7cac090-d91b-4f55-a834-4f3f9e0e83fa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Module No</value>
      <webElementGuid>b8caa696-42e7-4ada-bbb1-b24882e13438</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;profile&quot;)/table[@class=&quot;table table-responsive table-borderless&quot;]/thead[1]/tr[1]/th[3]</value>
      <webElementGuid>953d59a0-1af0-4c59-ab18-6f9b3f26acf8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='profile']/table[2]/thead/tr/th[3]</value>
      <webElementGuid>c041b3dd-b864-40d8-9eb4-bd3d71400cd1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Counter'])[1]/following::th[1]</value>
      <webElementGuid>a9f89f14-645a-4010-b9a4-aeeed1ca1e4a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Floor'])[2]/following::th[2]</value>
      <webElementGuid>4d4cd529-174b-4bcf-993e-13b3dcfd7458</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Area in Sq. Ft.'])[2]/preceding::th[1]</value>
      <webElementGuid>cfde135d-d5f7-492e-b55c-ea2190947968</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ready for Occupation'])[2]/preceding::th[2]</value>
      <webElementGuid>c82af64f-e91d-4aa9-924b-2ede9eb6f087</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//table[2]/thead/tr/th[3]</value>
      <webElementGuid>0c94b3c9-d691-45c7-911c-a116a21391fa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//th[(text() = 'Module No' or . = 'Module No')]</value>
      <webElementGuid>5eb3ac7b-6287-4f0a-8146-014bac06d312</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
