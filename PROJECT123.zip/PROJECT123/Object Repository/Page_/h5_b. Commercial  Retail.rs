<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h5_b. Commercial  Retail</name>
   <tag></tag>
   <elementGuidId>ea732ef2-63bd-4741-8679-0933f59b870a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h5.pb-30.pt-50</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='profile']/h5[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;b. Commercial / Retail&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h5</value>
      <webElementGuid>cb9baf7e-0684-4c7f-8ad1-cd0c42b3ff5e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>pb-30 pt-50</value>
      <webElementGuid>f3ba257f-14e6-4c32-9726-2aca3404834d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>b. Commercial / Retail</value>
      <webElementGuid>e5b46fec-21d6-4fa8-8251-e913988ef0f7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;profile&quot;)/h5[@class=&quot;pb-30 pt-50&quot;]</value>
      <webElementGuid>8d01722d-e716-488a-9044-283628e19d61</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='profile']/h5[2]</value>
      <webElementGuid>fb6ecccc-d487-4683-94f2-3efc97cbce9c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enquire'])[1]/following::h5[1]</value>
      <webElementGuid>cf38b2e8-76bf-45a7-af8a-f4ff84934f1b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Floor Status'])[1]/following::h5[1]</value>
      <webElementGuid>e93c694d-d45f-483d-85f9-5079c09d0f02</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Floor'])[2]/preceding::h5[1]</value>
      <webElementGuid>123b1241-7b07-4da9-b59a-937931fb2043</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Counter'])[1]/preceding::h5[1]</value>
      <webElementGuid>f76edf83-ebd1-4b15-8fd0-baf813d8ee3a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='b. Commercial / Retail']/parent::*</value>
      <webElementGuid>f738d092-52ab-4c52-9656-70667f2f60bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h5[2]</value>
      <webElementGuid>6a8a0b09-c025-44bc-b614-205e7ee528b0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h5[(text() = 'b. Commercial / Retail' or . = 'b. Commercial / Retail')]</value>
      <webElementGuid>55fd6428-e18a-4cf9-bca5-73f5ed850a5c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
