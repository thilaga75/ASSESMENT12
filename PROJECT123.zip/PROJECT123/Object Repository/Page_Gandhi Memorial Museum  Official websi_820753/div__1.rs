<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div__1</name>
   <tag></tag>
   <elementGuidId>c99669d7-3794-4216-8fb1-0afbdba058b7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#formpop</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='formpop']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#formpop</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>891ca3aa-1dae-497d-b9f3-53ffbf427796</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>formpop</value>
      <webElementGuid>d6bec8b3-609c-4204-b0b5-e73a1aaaabdc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>modal fade in</value>
      <webElementGuid>806108b8-cd38-4912-b47b-e2cd3a0e0c39</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

    

        

            

                ×

            

            

            
    
            
            

            

            
            
            
 




            

        

    

</value>
      <webElementGuid>bd2cd496-4fea-475f-926a-995ab7a73e25</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;formpop&quot;)</value>
      <webElementGuid>13b5f3aa-d30d-4fde-91ef-ce77911703f0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//div[@id='formpop']</value>
      <webElementGuid>d9f7837e-2f4a-4c16-9d8e-c67471aaeda4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='your web browser'])[1]/preceding::div[5]</value>
      <webElementGuid>bbfcf591-8bb3-445f-b45d-2bf7e02c62c5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div</value>
      <webElementGuid>22aa1cc9-b4b9-4a65-bebb-08a90796ea91</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[@id = 'formpop' and (text() = '

    

        

            

                ×

            

            

            
    
            
            

            

            
            
            
 




            

        

    

' or . = '

    

        

            

                ×

            

            

            
    
            
            

            

            
            
            
 




            

        

    

')]</value>
      <webElementGuid>c1a3f28c-d06a-4767-9784-b7af2c5f8066</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
