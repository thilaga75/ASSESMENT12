<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Eminent Visitors</name>
   <tag></tag>
   <elementGuidId>1cdf5beb-f355-46ee-a174-470eb389808a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.page_item.page-item-53 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[@id='pages-2']/ul/li[2]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Eminent Visitors&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>e462f34d-5aa3-43be-b9bc-94aafd860937</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>http://gandhimmm.org/eminent-visitors/</value>
      <webElementGuid>26ad5c08-17bd-49ef-97e1-b4863cfe7642</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Eminent Visitors</value>
      <webElementGuid>c79dfc01-69ee-4cbe-99e3-6bebdaa3985e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;pages-2&quot;)/ul[1]/li[@class=&quot;page_item page-item-53&quot;]/a[1]</value>
      <webElementGuid>473f597d-8f46-416a-9bad-2847ed434b16</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//li[@id='pages-2']/ul/li[2]/a</value>
      <webElementGuid>d8d67810-3f33-49fd-9381-03b4270b249f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Eminent Visitors')]</value>
      <webElementGuid>1c05f839-170e-4b9a-8ab0-e184434294ad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Activities of Gandhi Museum'])[1]/following::a[1]</value>
      <webElementGuid>b5762f1c-d75a-4553-97aa-063baf95da48</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Navigation'])[1]/following::a[2]</value>
      <webElementGuid>b8231f35-d38e-41ea-bb74-99e185e957ba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Former Chairpersons'])[1]/preceding::a[1]</value>
      <webElementGuid>e7bc83ff-1bdb-4671-b9cb-ca11bb01b45f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gandhi Museums in India'])[1]/preceding::a[2]</value>
      <webElementGuid>e79ddd79-3a60-4eaa-a4d4-fa885f34f12d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Eminent Visitors']/parent::*</value>
      <webElementGuid>e9000c17-16ad-499d-b804-3f64fcd78765</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[@href='http://gandhimmm.org/eminent-visitors/']</value>
      <webElementGuid>4bc6ddf1-fd92-493d-ac1d-1983084fbe7b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/ul/li[2]/a</value>
      <webElementGuid>669fdd2e-3e1d-44d7-9e9c-245e58c5b9b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'http://gandhimmm.org/eminent-visitors/' and (text() = 'Eminent Visitors' or . = 'Eminent Visitors')]</value>
      <webElementGuid>3c68db35-8fed-4c98-8967-e212bee69ffd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
