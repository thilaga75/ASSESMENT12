<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Gandhi Memorial Museum</name>
   <tag></tag>
   <elementGuidId>368afe54-0da5-4d84-a14b-a980c1c5af78</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;Gandhi Memorial Museum&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='site-title']/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Gandhi Memorial Museum&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>15437f0a-99fc-4838-bb7c-cd1e22b90671</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>http://gandhimmm.org/</value>
      <webElementGuid>808d2344-5e4f-42a4-b704-6568fcfdaa97</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Gandhi Memorial Museum</value>
      <webElementGuid>9d00586c-befd-4d68-9510-03b5bddf1810</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>rel</name>
      <type>Main</type>
      <value>home</value>
      <webElementGuid>775a4f1e-6281-4830-8967-607a59102ae6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
				  Gandhi Memorial Museum				  </value>
      <webElementGuid>f0ad8a8e-1bc5-442d-a820-42e476f04081</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;site-title&quot;)/a[1]</value>
      <webElementGuid>121ca215-a245-4b2b-afc2-a7beb48ce99e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='site-title']/a</value>
      <webElementGuid>bc3648ac-9819-4b34-a95a-68256e381321</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Gandhi Memorial Museum')]</value>
      <webElementGuid>8f395990-7583-43d7-b36a-fd41df31aa26</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact Us'])[1]/following::a[1]</value>
      <webElementGuid>cb23b051-a855-4b69-ba36-71d5162fd093</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About us'])[1]/following::a[2]</value>
      <webElementGuid>3135d694-e608-4942-9ec7-c6589669d635</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Official website of Gandhi Memorial Museum Madurai'])[1]/preceding::a[1]</value>
      <webElementGuid>ddb29c1b-08c7-4e82-86a2-61244d3cbb9d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Home'])[2]/preceding::a[1]</value>
      <webElementGuid>27c00b08-1bb7-4a5b-a3b6-a6a2c8580b70</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Gandhi Memorial Museum']/parent::*</value>
      <webElementGuid>177fc9f8-e1da-48b0-9adf-125262684bb9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[@href='http://gandhimmm.org/'])[2]</value>
      <webElementGuid>88050035-a875-45f4-b2a7-ead18eefb457</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/table/tbody/tr/td/div/a</value>
      <webElementGuid>18398471-b4dd-4d8d-b7b9-bca9bee6507a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'http://gandhimmm.org/' and @title = 'Gandhi Memorial Museum' and (text() = '
				  Gandhi Memorial Museum				  ' or . = '
				  Gandhi Memorial Museum				  ')]</value>
      <webElementGuid>417c9a25-4ba0-4aef-8a88-c259ef3eecb4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
